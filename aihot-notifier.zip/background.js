const feedState = typeof importScripts === 'function'
  ? (importScripts('feed-state.js'), globalThis.FeedState)
  : require('./feed-state.js');
const { normalizeFeedMode, normalizeHistoryDays, projectHistory } = feedState;
const watchRulesApi = typeof importScripts === 'function'
  ? (importScripts('watch-rules.js'), globalThis.WatchRules)
  : require('./watch-rules.js');
const { normalizeWatchRuleList, getEnabledWatchRules, matchWatchRules, getWatchAuthorLabel, hasActiveWatchMatch } = watchRulesApi;

const API_BASE = 'https://aihot.news/api/v1/items';
const API_WINDOW = '7d';
const API_LIMIT = 100;
const MAX_CURSOR_LENGTH = 1024;
const REQUEST_TIMEOUT_MS = 15000;
const ALARM_NAME = 'aihot-poll';
const ALL_CONTINUATION_ALARM_NAME = 'aihot-all-continuation';
const DEFAULT_INTERVAL = 5;
const MIN_INTERVAL = 2;
const DEFAULT_HISTORY_DAYS = 1;
const MAX_HISTORY_DAYS = 7;
const AUTO_POLL_DELAY_BUFFER_MS = 6 * 60 * 60 * 1000;
const BADGE_COLOR = '#e2231a';
const MAX_WATCH_NOTIFICATIONS_PER_CYCLE = 3;
const MAX_PENDING_NOTIFICATIONS = 100;
const MAX_PENDING_NOTIFICATIONS_PER_POLL = 1;
const SELECTED_MAX_PAGES = 3;
const ALL_MAX_PAGES = 20;
const MANUAL_MAX_PAGES = 3;
const ALL_CONTINUATION_MAX_429_RETRIES = 2;
const ALL_CONTINUATION_STATUS_TTL_MS = 15 * 60 * 1000;
const RETRY_AFTER_FALLBACK_MS = 45 * 1000;
const TEMPORARY_FAILURE_BACKOFF_MS = 5 * 60 * 1000;
const MAX_FAILURE_BACKOFF_MS = 60 * 60 * 1000;
const ITEMS_SAFETY_POLL_MS = 6 * 60 * 60 * 1000;
// Watch items notify once, as soon as they are first matched. Later reminders were removed.
const WATCH_REMINDER_DELAYS = [0];
const CANONICAL_HISTORY_VERSION = 1;
const API_NORMALIZATION_VERSION = 1;
const HISTORY_RETENTION_VERSION = 1;
const MAX_HISTORY_ENTRIES = 2500;
const MAX_MANAGED_STORAGE_BYTES = 6 * 1024 * 1024;
const MAX_TITLE_LENGTH = 500;
const MAX_SOURCE_LENGTH = 300;
const MAX_SUMMARY_LENGTH = 3000;
// Gated off until the API guarantees a consistent, un-paginated selected snapshot.
// While false, isCompleteSelectedSnapshot() always returns false in production, so the
// completeSelectedSnapshot de-selection branch in upsertCanonicalItems is unreachable
// outside tests (which pass capabilities explicitly). Do not enable without that guarantee:
// a truncated snapshot would wrongly de-select items missing from the partial page.
const SUPPORTS_CONSISTENT_SELECTED_SNAPSHOT = false;
const SOURCE_SWITCH_STORAGE_KEYS = [
  'history',
  'readIds',
  'lastItems',
  'watchNotifyState',
  'feedMode',
  'allFeedContinuation',
  'lastCheck',
  'failCount',
  'nextAllowedPollAt',
  'lastItemsPollAt'
];
let notificationCounter = 0;
let stateMutationQueue = Promise.resolve();
let badgeUpdateQueue = Promise.resolve();
let feedModeGeneration = 0;
let sourceSwitchGeneration = 0;
let canonicalHistoryMigrationPromise = null;

function runStateMutation(task) {
  const operation = stateMutationQueue.then(task, task);
  stateMutationQueue = operation.catch(() => {});
  return operation;
}

function migrateCanonicalHistoryState(data = {}) {
  const mode = normalizeFeedMode(data.feedMode);
  return {
    history: (data.history || []).map(item => ({
      ...item,
      selected: mode === 'selected' ? true : item?.selected === true
    })),
    canonicalHistoryVersion: CANONICAL_HISTORY_VERSION
  };
}

function ensureCanonicalHistoryMigration() {
  if (!canonicalHistoryMigrationPromise) {
    const migration = runStateMutation(async () => {
      const data = await chrome.storage.local.get(['canonicalHistoryVersion', 'apiNormalizationVersion', 'historyRetentionVersion', 'history', 'feedMode']);
      const updates = Number(data.canonicalHistoryVersion || 0) < CANONICAL_HISTORY_VERSION
        ? migrateCanonicalHistoryState(data) : {};
      if (Number(data.apiNormalizationVersion || 0) < API_NORMALIZATION_VERSION) {
        // Old ETags can hide items discarded by the previous normalizer.
        Object.assign(updates, {
          apiNormalizationVersion: API_NORMALIZATION_VERSION,
          apiFingerprintEtags: {},
          lastItemsPollAt: ''
        });
      }
      if (Number(data.historyRetentionVersion || 0) < HISTORY_RETENTION_VERSION) {
        Object.assign(updates, {
          historyRetentionVersion: HISTORY_RETENTION_VERSION,
          apiFingerprintEtags: {},
          lastItemsPollAt: ''
        });
      }
      if (Object.keys(updates).length > 0) await chrome.storage.local.set(updates);
    });
    canonicalHistoryMigrationPromise = migration;
    void migration.catch(() => {
      if (canonicalHistoryMigrationPromise === migration) canonicalHistoryMigrationPromise = null;
    });
  }
  return canonicalHistoryMigrationPromise;
}

function runMigratedStateMutation(task) {
  return ensureCanonicalHistoryMigration().then(() => runStateMutation(task));
}

function truncatePersistedValue(value, key = '') {
  if (typeof value === 'string') {
    const limit = key === 'title' ? MAX_TITLE_LENGTH
      : key === 'source' ? MAX_SOURCE_LENGTH
      : key === 'summary' ? MAX_SUMMARY_LENGTH
      : 4096;
    return value.slice(0, limit);
  }
  if (Array.isArray(value)) return value.map(entry => truncatePersistedValue(entry, key));
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([childKey, childValue]) => [childKey, truncatePersistedValue(childValue, childKey)]));
  }
  return value;
}

function getManagedStorageBytes(state) {
  const json = JSON.stringify({
    history: state.history || [],
    readIds: state.readIds || [],
    watchNotifyState: state.watchNotifyState || {},
    lastItems: state.lastItems || [],
    allFeedContinuation: state.allFeedContinuation || null
  });
  return new TextEncoder().encode(json).length;
}

function retainReadIdsForHistory(readIds, history, keepUnmatched = true) {
  const aliases = [...new Set((readIds || []).filter(value => typeof value === 'string'))];
  const retainedAliases = new Set((history || []).flatMap(item => getItemAliases(item)));
  const unmatched = keepUnmatched
    ? new Set(aliases.filter(alias => !retainedAliases.has(alias)).slice(-100))
    : new Set();
  return aliases.filter(alias => retainedAliases.has(alias) || unmatched.has(alias));
}

function boundCanonicalStorageState(state = {}) {
  let history = (state.history || [])
    .map(item => truncatePersistedValue(item))
    .sort((a, b) => getItemTime(b) - getItemTime(a))
    .slice(0, MAX_HISTORY_ENTRIES);
  const buildState = () => {
    // Trimmed items fall into the bounded out-of-cache set (latest 100 keys by first-read
    // order), matching the documented contract. 100 short keys are negligible in the budget.
    const readIds = retainReadIdsForHistory(state.readIds, history);
    const retainedAliases = new Set(history.flatMap(item => getItemAliases(item)));
    const watchNotifyState = state.retainUnmatchedWatchState
      ? { ...(state.watchNotifyState || {}) }
      : Object.fromEntries(Object.entries(state.watchNotifyState || {})
        .filter(([key]) => retainedAliases.has(key)));
    const lastItems = (state.lastItems || []).filter(item => getItemAliases(item).some(alias => retainedAliases.has(alias))).slice(0, 5);
    const allFeedContinuation = state.allFeedContinuation == null
      ? state.allFeedContinuation
      : truncatePersistedValue(state.allFeedContinuation, 'allFeedContinuation');
    return { history, readIds, watchNotifyState, lastItems, allFeedContinuation };
  };
  let bounded = buildState();
  while (getManagedStorageBytes(bounded) > MAX_MANAGED_STORAGE_BYTES && history.length > 0) {
    const bytes = getManagedStorageBytes(bounded);
    const removeCount = Math.max(1, Math.ceil(history.length * (1 - (MAX_MANAGED_STORAGE_BYTES / bytes))));
    history.splice(Math.max(0, history.length - removeCount), removeCount);
    bounded = buildState();
  }
  if (getManagedStorageBytes(bounded) > MAX_MANAGED_STORAGE_BYTES) {
    bounded.allFeedContinuation = null;
    bounded.watchNotifyState = {};
    bounded.lastItems = [];
    bounded.readIds = [];
  }
  return bounded;
}

function isQuotaStorageError(error) {
  return /quota|QUOTA_BYTES|bytes/i.test(String(error?.message || error || ''));
}

async function persistCanonicalState(updates = {}) {
  // retainUnmatchedWatchState is a bounding hint only; never persist it as a storage key.
  const { retainUnmatchedWatchState: _retainHint, ...storedUpdates } = updates;
  const bounded = boundCanonicalStorageState(updates);
  const payload = {
    ...storedUpdates,
    history: bounded.history,
    readIds: bounded.readIds,
    watchNotifyState: bounded.watchNotifyState,
    ...(Object.prototype.hasOwnProperty.call(updates, 'allFeedContinuation') ? { allFeedContinuation: bounded.allFeedContinuation } : {}),
    ...(Object.prototype.hasOwnProperty.call(updates, 'lastItems') ? { lastItems: bounded.lastItems } : {})
  };
  try {
    await chrome.storage.local.set(payload);
    return payload;
  } catch (error) {
    if (!isQuotaStorageError(error) || bounded.history.length <= 1) throw error;
    const retryState = boundCanonicalStorageState({
      ...bounded,
      retainUnmatchedWatchState: updates.retainUnmatchedWatchState === true,
      history: bounded.history.slice(0, Math.max(1, Math.floor(bounded.history.length / 2)))
    });
    const retryPayload = {
      ...storedUpdates,
      history: retryState.history,
      readIds: retryState.readIds,
      watchNotifyState: retryState.watchNotifyState,
      ...(Object.prototype.hasOwnProperty.call(updates, 'allFeedContinuation') ? { allFeedContinuation: retryState.allFeedContinuation } : {}),
      ...(Object.prototype.hasOwnProperty.call(updates, 'lastItems') ? { lastItems: retryState.lastItems } : {})
    };
    await chrome.storage.local.set(retryPayload);
    return retryPayload;
  }
}

async function getConfig() {
  const data = await chrome.storage.local.get(['enabled', 'interval', 'lastCheck', 'feedMode']);
  return {
    enabled: data.enabled !== false,
    interval: Math.max(Number(data.interval) || DEFAULT_INTERVAL, MIN_INTERVAL),
    lastCheck: data.lastCheck || new Date().toISOString(),
    feedMode: normalizeFeedMode(data.feedMode)
  };
}

function getApiUrl(mode) {
  return `${API_BASE}?mode=${encodeURIComponent(normalizeFeedMode(mode))}&window=${API_WINDOW}&limit=${API_LIMIT}`;
}

function getMaxPages(mode) {
  return normalizeFeedMode(mode) === 'all' ? ALL_MAX_PAGES : SELECTED_MAX_PAGES;
}

function sleep(ms) {
  if (!ms || ms <= 0) return Promise.resolve();
  return new Promise(resolve => setTimeout(resolve, ms));
}

function getResponseHeader(response, name) {
  if (!response || !response.headers) return '';
  if (typeof response.headers.get === 'function') return response.headers.get(name) || '';
  return response.headers[name] || response.headers[name.toLowerCase()] || '';
}

function getRetryAfterMs(response, status, failureCount = 1) {
  const retryAfter = getResponseHeader(response, 'Retry-After');
  if (retryAfter) {
    const seconds = Number(retryAfter);
    if (Number.isFinite(seconds) && seconds >= 0) return seconds * 1000;
    const dateMs = new Date(retryAfter).getTime();
    if (dateMs > Date.now()) return dateMs - Date.now();
  }
  if (status === 429) return RETRY_AFTER_FALLBACK_MS;
  if (status >= 500 && status < 600) {
    const exponent = Math.min(4, Math.max(0, Number(failureCount) - 1 || 0));
    return Math.min(MAX_FAILURE_BACKOFF_MS, TEMPORARY_FAILURE_BACKOFF_MS * (2 ** exponent));
  }
  return 0;
}

async function recordApiFailure(responseOrStatus) {
  const status = typeof responseOrStatus === 'number' ? responseOrStatus : responseOrStatus?.status;
  const failureCount = await incrementFailCount();
  const backoffMs = getRetryAfterMs(responseOrStatus, status, failureCount);
  if (backoffMs > 0) {
    await chrome.storage.local.set({ nextAllowedPollAt: new Date(Date.now() + backoffMs).toISOString() });
  }
}

function getItemOpenUrl(item) {
  return item && (item.url || item.permalink || '');
}

function getSafeHttpsUrl(value) {
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:' ? parsed.href : '';
  } catch (_e) {
    return '';
  }
}

function getItemStateKey(item) {
  return item && (item.id || item.permalink || item.url || '');
}

function getItemAliases(itemOrKey) {
  if (!itemOrKey) return [];
  if (typeof itemOrKey === 'string') return [itemOrKey].filter(Boolean);
  return [getItemStateKey(itemOrKey), itemOrKey.id, itemOrKey.permalink, itemOrKey.url]
    .filter(Boolean)
    .filter((value, index, arr) => arr.indexOf(value) === index);
}

function getDiscoveredAtAliases(item) {
  if (!item) return [];
  return [
    item.id ? `id:${item.id}` : '',
    item.permalink ? `permalink:${item.permalink}` : '',
    item.url ? `url:${item.url}` : ''
  ].filter(Boolean);
}

function buildDiscoveredAtByAlias(history, limit = Infinity) {
  const entries = new Map();
  const indexedHistory = Number.isFinite(limit) ? (history || []).slice(0, limit) : (history || []);
  indexedHistory.forEach(item => {
    const discoveredAt = item.discoveredAt || item.time || '';
    if (!discoveredAt || !Number.isFinite(new Date(discoveredAt).getTime())) return;
    const alias = getDiscoveredAtAliases(item)[0];
    if (!alias) return;
    const existing = entries.get(alias);
    if (!existing || new Date(discoveredAt) < new Date(existing)) entries.set(alias, discoveredAt);
  });
  return Object.fromEntries(entries);
}

function getKnownDiscoveredAt(item, discoveredAtByAlias, fallback) {
  const known = getDiscoveredAtAliases(item)
    .map(alias => discoveredAtByAlias?.[alias])
    .find(value => value && Number.isFinite(new Date(value).getTime()));
  return known || fallback;
}

function getLegacyDiscoveredAtFallback(item, discoveredAtByAlias, fallback) {
  const exactId = item?.id ? discoveredAtByAlias?.[`id:${item.id}`] : '';
  if (exactId && Number.isFinite(new Date(exactId).getTime())) return exactId;
  const aliasMatches = getDiscoveredAtAliases(item)
    .filter(alias => !alias.startsWith('id:'))
    .map(alias => discoveredAtByAlias?.[alias])
    .filter(value => value && Number.isFinite(new Date(value).getTime()));
  return aliasMatches.length === 1 ? aliasMatches[0] : fallback;
}

function isSafetyItemsPollDue(lastItemsPollAt) {
  const last = new Date(lastItemsPollAt || 0).getTime();
  return !last || Date.now() - last >= ITEMS_SAFETY_POLL_MS;
}

function getAutoPollSinceTime(config, _safetyPollDue, lastItemsPollAt) {
  const bufferMs = Math.max(config.interval * 2 * 60 * 1000, AUTO_POLL_DELAY_BUFFER_MS);
  const referenceTime = lastItemsPollAt || config.lastCheck;
  return new Date(new Date(referenceTime).getTime() - bufferMs).toISOString();
}

async function probeItemsEtag(mode) {
  const normalizedMode = normalizeFeedMode(mode);
  return { ok: true, changed: true, etagUrl: getApiUrl(normalizedMode) };
}

async function saveFingerprintProbe(probe) {
  if (!probe) return;
  const data = {};
  if (probe.etagUrl) {
    const { apiFingerprintEtags = {} } = await chrome.storage.local.get('apiFingerprintEtags');
    const nextEtags = { ...apiFingerprintEtags };
    if (probe.etag) nextEtags[probe.etagUrl] = probe.etag;
    else delete nextEtags[probe.etagUrl];
    data.apiFingerprintEtags = nextEtags;
  }
  if (Object.keys(data).length > 0) await chrome.storage.local.set(data);
}

async function withRequestDeadline(url, options, handleResponse) {
  const controller = new AbortController();
  let timeoutId;
  let response;
  const deadline = new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      const error = new Error(`Request timed out after ${REQUEST_TIMEOUT_MS}ms`);
      // Keep HTTP failure semantics even if decoding the error body stalls.
      if (response?.status >= 400) Object.assign(error, { response, status: response.status });
      reject(error);
      controller.abort();
    }, REQUEST_TIMEOUT_MS);
  });

  try {
    const request = fetch(url, { ...(options || {}), signal: controller.signal })
      .then(res => {
        response = res;
        return handleResponse(res);
      });
    return await Promise.race([request, deadline]);
  } finally {
    clearTimeout(timeoutId);
  }
}

async function fetchItemsPageWithOptions(url, options) {
  return withRequestDeadline(url, options, async res => {
    if (res.status === 304) return { notModified: true, etag: getResponseHeader(res, 'ETag'), json: null };
    if (!res.ok) {
      let problem;
      try {
        problem = await res.json();
      } catch (_error) {
        // Edge failures can return HTML, an empty body, or malformed JSON.
      }
      const code = typeof problem?.code === 'string' ? problem.code.slice(0, 200) : '';
      const detail = typeof problem?.detail === 'string' ? problem.detail.slice(0, 2000) : '';
      const requestId = (typeof problem?.requestId === 'string' && problem.requestId
        ? problem.requestId : getResponseHeader(res, 'X-Request-Id')).slice(0, 200);
      const message = `API returned ${res.status}${code ? ` (${code})` : ''}${requestId ? ` [requestId: ${requestId}]` : ''}`;
      throw Object.assign(new Error(message), { response: res, status: res.status, code, detail, requestId });
    }
    return { notModified: false, etag: getResponseHeader(res, 'ETag'), json: await res.json() };
  });
}

const fetchItemsPage = url => fetchItemsPageWithOptions(url);

function isHttpsUrl(value) {
  try {
    return new URL(value).protocol === 'https:';
  } catch (_e) {
    return false;
  }
}

function normalizeAttribution(attribution) {
  if (!attribution || typeof attribution !== 'object') return null;
  const name = typeof attribution.name === 'string' ? attribution.name : '';
  const url = typeof attribution.url === 'string' ? attribution.url : '';
  return name || url ? { name, url } : null;
}

function normalizeTimestamp(value) {
  if (typeof value !== 'string' || !value.trim()) return '';
  const timestamp = new Date(value).getTime();
  return Number.isFinite(timestamp) ? new Date(timestamp).toISOString() : '';
}

function normalizeV1Item(item) {
  if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
  if (typeof item.id !== 'string' || !item.id || typeof item.title !== 'string' || !item.title) return null;
  if (!item.source || typeof item.source !== 'object' || typeof item.source.name !== 'string' || !item.source.name) return null;
  if (!item.links || typeof item.links !== 'object') return null;

  const original = typeof item.links.original === 'string' ? item.links.original : '';
  const permalink = typeof item.links.aihot === 'string' ? item.links.aihot : '';
  const url = isHttpsUrl(original) ? original : (isHttpsUrl(permalink) ? permalink : '');
  if (!url) return null;
  const indexedAt = normalizeTimestamp(item.indexedAt);
  const sourceDiscoveredAt = normalizeTimestamp(item.discoveredAt);
  const publishedAt = normalizeTimestamp(item.publishedAt);
  if (!publishedAt && !sourceDiscoveredAt && !indexedAt) return null;

  return {
    ...item,
    publishedAt,
    indexedAt,
    sourceDiscoveredAt,
    selectedPresent: Object.prototype.hasOwnProperty.call(item, 'selected'),
    selected: item.selected === true,
    source: item.source.name,
    url,
    permalink,
    titleEn: typeof item.originalTitle === 'string' ? item.originalTitle : '',
    attribution: normalizeAttribution(item.attribution)
  };
}

function getV1Page(json) {
  if (!json || typeof json !== 'object' || Array.isArray(json) || !Array.isArray(json.items)) {
    throw new Error('Invalid API items response');
  }
  if (!json.page || typeof json.page !== 'object' || Array.isArray(json.page) || typeof json.page.hasMore !== 'boolean') {
    throw new Error('Invalid API page response');
  }

  const nextCursor = json.page.nextCursor;
  if (nextCursor !== null && nextCursor !== undefined && typeof nextCursor !== 'string') {
    throw new Error('Invalid API cursor');
  }
  if (typeof nextCursor === 'string' && nextCursor.length > MAX_CURSOR_LENGTH) {
    throw new Error('API cursor is too long');
  }
  if (json.page.hasMore && !nextCursor) throw new Error('Missing API cursor');

  return { items: json.items, hasMore: json.page.hasMore, nextCursor: nextCursor || '' };
}

async function fetchItems({ mode, cutoff = -Infinity, maxPages = getMaxPages(mode), baseUrl = '', supportsMonotonicOrder = false, bypassEtag = false }) {
  const normalizedMode = normalizeFeedMode(mode);
  let allItems = [];
  let cursor = null;
  let truncated = false;
  let nextCursor = '';
  let skippedItems = 0;
  let etag = '';
  let termination = 'page-bound';
  const seenCursors = new Set();

  for (let page = 0; page < maxPages; page++) {
    let url = baseUrl || getApiUrl(normalizedMode);
    if (cursor) url += `&cursor=${encodeURIComponent(cursor)}`;

    const { apiFingerprintEtags = {} } = page === 0 ? await chrome.storage.local.get('apiFingerprintEtags') : { apiFingerprintEtags: {} };
    const requestOptions = page === 0 && !bypassEtag && apiFingerprintEtags[url] ? { headers: { 'If-None-Match': apiFingerprintEtags[url] } } : undefined;
    const pageResult = await fetchItemsPageWithOptions(url, requestOptions);
    if (pageResult.notModified) {
      allItems.notModified = true;
      etag = pageResult.etag || apiFingerprintEtags[url] || '';
      break;
    }
    if (page === 0) etag = pageResult.etag || '';
    const response = getV1Page(pageResult.json);
    const items = response.items.map(normalizeV1Item).filter(Boolean);
    skippedItems += response.items.length - items.length;
    allItems = allItems.concat(items);

    if (!response.hasMore) {
      termination = 'complete';
      break;
    }
    const oldest = items[items.length - 1];
    if (supportsMonotonicOrder === true && oldest && new Date(getNormalizedItemTime(oldest)).getTime() < cutoff) {
      termination = 'cutoff';
      truncated = true;
      nextCursor = response.nextCursor;
      break;
    }
    if (page === maxPages - 1) {
      truncated = true;
      nextCursor = response.nextCursor;
      break;
    }
    if (seenCursors.has(response.nextCursor)) throw new Error('Repeated API cursor');
    seenCursors.add(response.nextCursor);
    cursor = response.nextCursor;
  }

  allItems.truncated = truncated;
  allItems.nextCursor = nextCursor;
  allItems.skippedItems = skippedItems;
  allItems.termination = termination;
  allItems.etag = etag;
  return allItems;
}

function isCompleteSelectedSnapshot(items, mode, supportsConsistentSnapshot = SUPPORTS_CONSISTENT_SELECTED_SNAPSHOT) {
  return supportsConsistentSnapshot === true &&
    normalizeFeedMode(mode) === 'selected' &&
    items?.termination === 'complete' &&
    Number(items?.skippedItems || 0) === 0 &&
    items?.truncated !== true;
}

function getActiveWatchMatchIds(historyItem, watchRules) {
  const normalizedRules = getEnabledWatchRules(watchRules);
  if (!historyItem || !historyItem.watchMatched || !Array.isArray(historyItem.watchRuleIds) || historyItem.watchRuleIds.length === 0) {
    return [];
  }
  const activeRuleIds = new Set(normalizedRules.map(rule => rule.id));
  return historyItem.watchRuleIds.filter(ruleId => activeRuleIds.has(ruleId));
}

function getNextWatchNotifyAt(firstMatchedAt, notifyCount, referenceNow) {
  const first = new Date(firstMatchedAt).getTime();
  if (!first) return '';
  if (notifyCount < WATCH_REMINDER_DELAYS.length) {
    return new Date(first + WATCH_REMINDER_DELAYS[notifyCount]).toISOString();
  }
  return '';
}

function isWatchViewed(state) {
  return Boolean(state && state.viewedAt);
}

function buildWatchStateForItem(existingState, item, ruleIds, now) {
  const current = existingState || {};
  const firstMatchedAt = current.firstMatchedAt || now;
  const notifyCount = Number(current.notifyCount || 0);
  return {
    ruleIds: Array.from(new Set([...(current.ruleIds || []), ...ruleIds])),
    firstMatchedAt,
    lastNotifiedAt: current.lastNotifiedAt || '',
    notifyCount,
    nextNotifyAt: current.nextNotifyAt || getNextWatchNotifyAt(firstMatchedAt, notifyCount, now),
    viewedAt: current.viewedAt || ''
  };
}

function shouldNotifyWatchState(state, nowMs) {
  if (!state || isWatchViewed(state)) return false;
  // Items first matched outside the display window are tagged silently.
  if (state.suppressedAt) return false;
  // Stored states from the old 8h/24h schedule may still carry a future nextNotifyAt.
  if (Number(state.notifyCount || 0) >= WATCH_REMINDER_DELAYS.length) return false;
  const nextNotifyAt = Object.prototype.hasOwnProperty.call(state, 'nextNotifyAt') ? state.nextNotifyAt : state.firstMatchedAt;
  const next = new Date(nextNotifyAt || 0).getTime();
  return next > 0 && next <= nowMs;
}

function advanceWatchNotifyState(state, now) {
  const notifyCount = Number(state.notifyCount || 0) + 1;
  return {
    ...state,
    lastNotifiedAt: now,
    notifyCount,
    nextNotifyAt: getNextWatchNotifyAt(state.firstMatchedAt || now, notifyCount, now)
  };
}

function getWatchNotificationTitle(item) {
  return `特关：${getWatchAuthorLabel(item.source) || '特关'}`;
}

async function rememberNotificationUrl(id, url) {
  if (!url) return;
  const { notificationUrlMap = {} } = await chrome.storage.local.get('notificationUrlMap');
  await chrome.storage.local.set({
    notificationUrlMap: {
      ...notificationUrlMap,
      [id]: url
    }
  });
}

async function rememberNotificationStateKey(id, key) {
  if (!key) return;
  const { notificationStateKeyMap = {} } = await chrome.storage.local.get('notificationStateKeyMap');
  await chrome.storage.local.set({
    notificationStateKeyMap: {
      ...notificationStateKeyMap,
      [id]: key
    }
  });
}

async function forgetNotificationUrl(id) {
  const { notificationUrlMap = {}, notificationStateKeyMap = {} } = await chrome.storage.local.get(['notificationUrlMap', 'notificationStateKeyMap']);
  if (!notificationUrlMap[id] && !notificationStateKeyMap[id]) return;
  const nextMap = { ...notificationUrlMap };
  const nextStateKeyMap = { ...notificationStateKeyMap };
  delete nextMap[id];
  delete nextStateKeyMap[id];
  await chrome.storage.local.set({ notificationUrlMap: nextMap, notificationStateKeyMap: nextStateKeyMap });
}

function getNotificationId(prefix) {
  notificationCounter = (notificationCounter + 1) % Number.MAX_SAFE_INTEGER;
  const randomPart = globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function'
    ? globalThis.crypto.randomUUID()
    : `${Date.now()}-${notificationCounter}`;
  return `${prefix}-${randomPart}`;
}

async function createNotification(id, options, url, stateKey = '') {
  try {
    await rememberNotificationUrl(id, url);
    await rememberNotificationStateKey(id, stateKey);
    await chrome.notifications.create(id, options);
  } catch (e) {
    await forgetNotificationUrl(id).catch(() => {});
    throw e;
  }
}

async function flushPendingNotifications(cycle = { sent: 0 }) {
  const { pendingNotifications = [] } = await chrome.storage.local.get('pendingNotifications');
  if (!Array.isArray(pendingNotifications)) return;

  while (pendingNotifications.length > 0 && cycle.sent < MAX_PENDING_NOTIFICATIONS_PER_POLL) {
    const pending = pendingNotifications[0];
    try {
      await createNotification(pending.id, pending.options, pending.url);
      pendingNotifications.shift();
      await chrome.storage.local.set({ pendingNotifications });
      cycle.sent++;
    } catch (e) {
      console.warn('[AI HOT] pending notification delivery failed:', e);
      return;
    }
  }
}

async function enqueueNotification(id, options, url, count, cycle) {
  const { pendingNotifications = [] } = await chrome.storage.local.get('pendingNotifications');
  const next = Array.isArray(pendingNotifications) ? [...pendingNotifications] : [];
  const pending = { id, options, url, count };
  if (next.length < MAX_PENDING_NOTIFICATIONS) {
    next.push(pending);
  } else {
    const summary = next[next.length - 1];
    summary.count = Number(summary.count || 1) + count;
    summary.options = {
      ...summary.options,
      title: `AI HOT 有 ${summary.count} 条新内容`,
      message: options.message,
      contextMessage: options.contextMessage
    };
    summary.url = url;
  }
  await chrome.storage.local.set({ pendingNotifications: next });
  await flushPendingNotifications(cycle);
}

function findWatchState(watchNotifyState, item) {
  const aliases = getItemAliases(item);
  const key = aliases.find(alias => watchNotifyState[alias]);
  return {
    key: key || getItemStateKey(item),
    state: key ? watchNotifyState[key] : null
  };
}

async function persistWatchNotificationProgress(committed, watchNotifyState, lastItems = committed.lastItems) {
  const updates = {
    history: committed.history,
    readIds: committed.readIds,
    watchNotifyState,
    ...(lastItems ? { lastItems: lastItems.slice(0, 5) } : {})
  };
  let saved;
  try {
    saved = await persistCanonicalState(updates);
  } catch (e) {
    // Quota has already had its one smaller-history retry. Retry only a
    // transient non-quota write, without sending the notification again.
    if (isQuotaStorageError(e)) throw e;
    saved = await persistCanonicalState(updates);
  }
  // Quota recovery can trim more items; do not notify or restore their state.
  Object.keys(watchNotifyState).forEach(key => { delete watchNotifyState[key]; });
  Object.assign(watchNotifyState, saved.watchNotifyState);
  return saved;
}

async function sendWatchNotifications(items, watchNotifyState, now, limit, persistProgress, cycle = { attempted: new Set(), sent: 0 }) {
  if (!Number.isFinite(limit) || limit <= 0) return [];
  const nowMs = new Date(now).getTime();
  const dueItems = items
    .filter(item => !cycle.attempted.has(getItemStateKey(item)) && shouldNotifyWatchState(findWatchState(watchNotifyState, item).state, nowMs))
    .sort((a, b) => getItemTime(b) - getItemTime(a))
    .slice(0, Math.min(Math.floor(limit), getCycleWatchNotificationBudget(cycle.sent)));
  const notified = [];

  for (let index = 0; index < dueItems.length; index++) {
    const item = dueItems[index];
    const { key, state } = findWatchState(watchNotifyState, item);
    if (!shouldNotifyWatchState(state, nowMs)) continue;
    cycle.attempted.add(getItemStateKey(item));
    try {
      await createNotification(getNotificationId('aihot-watch'), {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: getWatchNotificationTitle(item),
        message: item.title,
        contextMessage: item.source || ''
      }, getItemOpenUrl(item), key);
    } catch (e) {
      console.warn('[AI HOT] watch notification failed:', e);
      continue;
    }
    cycle.sent++;
    notified.push(item);
    watchNotifyState[key] = advanceWatchNotifyState(state, now);
    await runPostCommitSideEffect('watch notification progress', () => persistProgress(notified));
  }

  return notified;
}

async function markWatchViewed(urls, options = {}) {
  const list = Array.isArray(urls) ? urls : [urls];
  const filtered = [...new Set(list.flatMap(getItemAliases).filter(Boolean))];
  if (filtered.length === 0) return;
  const { watchNotifyState = {} } = await chrome.storage.local.get('watchNotifyState');
  const now = new Date().toISOString();
  filtered.forEach(value => {
    const aliases = getItemAliases(value);
    aliases.forEach(alias => {
      if (watchNotifyState[alias]) {
        watchNotifyState[alias] = { ...watchNotifyState[alias], viewedAt: watchNotifyState[alias].viewedAt || now };
      }
    });
  });
  await chrome.storage.local.set({ watchNotifyState });
  if (options.skipBadge !== true) await runPostCommitSideEffect('watch viewed badge update', updateBadge);
}

async function markItemsRead(ids, options = {}) {
  const aliases = [...new Set((Array.isArray(ids) ? ids : [ids]).flatMap(getItemAliases).filter(Boolean))];
  const { readIds = [], history = [] } = await chrome.storage.local.get(['readIds', 'history']);
  const merged = [...new Set([...readIds, ...aliases])];
  const bounded = retainReadIdsForHistory(merged, history);
  await chrome.storage.local.set({ readIds: bounded });
  if (options.skipBadge !== true) await runPostCommitSideEffect('mark-read badge update', updateBadge);
  return bounded;
}

// 只看特关时的「全部已读」：只标记当前可见、点击前已有的特关未读条目，不推进全局 readAllBefore，
// 被过滤掉的普通条目保持原未读状态。可见口径与 updateBadgeInternal 一致。
async function markWatchItemsReadBefore(candidate) {
  const candidateTime = new Date(candidate).getTime();
  const data = await chrome.storage.local.get(['history', 'readIds', 'readAllBefore', 'readAllBeforeByMode', 'historyDays', 'feedMode', 'watchRules', 'watchNotifyState']);
  const { history = [], readIds = [], historyDays = DEFAULT_HISTORY_DAYS, feedMode, watchRules = [] } = data;
  const readIdSet = new Set(readIds);
  const readAllBefore = getReadAllBefore(data);
  const readAllBeforeTime = readAllBefore ? new Date(readAllBefore).getTime() : 0;
  const cutoff = Date.now() - normalizeHistoryDays(historyDays) * 24 * 60 * 60 * 1000;
  const activeWatchRules = normalizeWatchRuleList(watchRules);
  const targets = projectHistory(history, feedMode).filter(item => {
    if (!isWithinDisplayWindow(item, cutoff) || !hasActiveWatchMatch(item, activeWatchRules)) return false;
    const referenceTime = getUnreadReferenceTime(item);
    // 点击之后才到达的条目不在用户确认范围内。
    if (referenceTime > candidateTime) return false;
    if (getItemAliases(item).some(alias => readIdSet.has(alias))) return false;
    return !(readAllBeforeTime && referenceTime <= readAllBeforeTime);
  });
  if (targets.length === 0) return 0;

  const aliases = [...new Set(targets.flatMap(getItemAliases))];
  const watchNotifyState = { ...(data.watchNotifyState || {}) };
  aliases.forEach(alias => {
    if (watchNotifyState[alias]) {
      watchNotifyState[alias] = { ...watchNotifyState[alias], viewedAt: watchNotifyState[alias].viewedAt || candidate };
    }
  });
  // 已读与特关已查看同次写入，避免只成功一半。
  await chrome.storage.local.set({
    readIds: retainReadIdsForHistory([...new Set([...readIds, ...aliases])], history),
    watchNotifyState
  });
  return targets.length;
}

async function openItem(urlValue, ids) {
  const url = getSafeHttpsUrl(urlValue);
  if (!url) return { ok: false, reason: 'unsafe-url' };
  try {
    await chrome.tabs.create({ url });
  } catch (_e) {
    return { ok: false, reason: 'tab-create-failed' };
  }

  const aliases = [...new Set([...(Array.isArray(ids) ? ids : [ids]), url].flatMap(getItemAliases).filter(Boolean))];
  try {
    await runMigratedStateMutation(async () => {
      await markItemsRead(aliases, { skipBadge: true });
      await markWatchViewed(aliases, { skipBadge: true });
      await runPostCommitSideEffect('open-item badge update', updateBadge);
    });
    return { ok: true, opened: true, readCommitted: true };
  } catch (error) {
    return { ok: true, opened: true, readCommitted: false, error: error.message || 'read persistence failed' };
  }
}

function retagHistoryForWatchRules(history, watchNotifyState, watchRules, now) {
  const nextWatchNotifyState = { ...(watchNotifyState || {}) };
  let changed = false;
  const nextHistory = (history || []).map(item => {
    const ruleIds = matchWatchRules(item, watchRules).map(rule => rule.id);
    const { key, state } = findWatchState(nextWatchNotifyState, item);
    if (ruleIds.length === 0) {
      if (!item.watchMatched && !Object.prototype.hasOwnProperty.call(item, 'watchRuleIds')) return item;
      // No longer matched: drop the tag and any pending notice for this item.
      const { watchMatched, watchRuleIds, watchMatchedAt, ...rest } = item;
      getItemAliases(item).forEach(alias => { delete nextWatchNotifyState[alias]; });
      changed = true;
      return rest;
    }
    const previous = Array.isArray(item.watchRuleIds) ? item.watchRuleIds : [];
    if (item.watchMatched === true && previous.length === ruleIds.length && ruleIds.every(id => previous.includes(id))) return item;
    if (state) nextWatchNotifyState[key] = { ...state, ruleIds };
    changed = true;
    // Cached items matched by a rule edit are tagged and pinned, but never notified.
    return { ...item, watchMatched: true, watchRuleIds: ruleIds, watchMatchedAt: item.watchMatched === true && item.watchMatchedAt ? item.watchMatchedAt : now };
  });
  return { history: nextHistory, watchNotifyState: nextWatchNotifyState, changed };
}

async function saveWatchRules(rules) {
  const { watchRules: storedWatchRules = [], history = [], readIds = [], watchNotifyState = {} } = await chrome.storage.local.get(['watchRules', 'history', 'readIds', 'watchNotifyState']);
  const watchRules = normalizeWatchRuleList(Array.isArray(rules) ? rules : storedWatchRules);
  const retagged = retagHistoryForWatchRules(history, watchNotifyState, watchRules, new Date().toISOString());
  if (retagged.changed) {
    // Reordering or toggling rules usually leaves tags unchanged; only rewrite history when needed,
    // and keep the rewrite inside the shared storage budget.
    await persistCanonicalState({ watchRules, history: retagged.history, readIds, watchNotifyState: retagged.watchNotifyState, retainUnmatchedWatchState: true });
  } else {
    await chrome.storage.local.set({ watchRules });
  }
  await runPostCommitSideEffect('watch rules badge update', updateBadge);
  return watchRules;
}

async function assertNotInBackoff() {
  const { nextAllowedPollAt = '' } = await chrome.storage.local.get('nextAllowedPollAt');
  if (nextAllowedPollAt && new Date(nextAllowedPollAt).getTime() > Date.now()) {
    throw Object.assign(new Error(`polling paused until ${nextAllowedPollAt}`), { backoff: true, nextAllowedPollAt });
  }
}

async function commitSuccessfulItemsPoll(data = {}) {
  const { now: providedNow, ...rest } = data;
  const now = providedNow || new Date().toISOString();
  await chrome.storage.local.set({
    ...rest,
    lastCheck: now,
    lastItemsPollAt: now,
    failCount: 0,
    nextAllowedPollAt: ''
  });
}

function getIdentityAliases(item) {
  return [item?.permalink, item?.url].filter(Boolean);
}

function findAliasCandidates(history, item) {
  const aliases = new Set(getIdentityAliases(item));
  return (history || [])
    .map((candidate, index) => ({ candidate, index }))
    .filter(({ candidate }) => getIdentityAliases(candidate).some(alias => aliases.has(alias)))
    .map(({ index }) => index);
}

function findLegacyDuplicates(history, item, winnerIndex) {
  const aliasCandidates = findAliasCandidates(history, item);
  const candidates = aliasCandidates
    .filter(index => index !== winnerIndex && !history[index].id);
  const conflictingId = aliasCandidates
    .some(index => index !== winnerIndex && Boolean(history[index].id));
  return !conflictingId && candidates.length === 1 ? candidates : [];
}

function earliestIso(values) {
  return (values || [])
    .filter(value => value && Number.isFinite(new Date(value).getTime()))
    .sort((a, b) => new Date(a) - new Date(b))[0] || '';
}

function latestIso(values) {
  return (values || [])
    .filter(value => value && Number.isFinite(new Date(value).getTime()))
    .sort((a, b) => new Date(b) - new Date(a))[0] || '';
}

function findCanonicalMatch(history, item) {
  const exactIndex = item.id ? history.findIndex(candidate => candidate.id === item.id) : -1;
  if (exactIndex >= 0) {
    return { index: exactIndex, legacyIndexes: findLegacyDuplicates(history, item, exactIndex) };
  }
  const candidates = findAliasCandidates(history, item);
  return candidates.length === 1 && !history[candidates[0]].id
    ? { index: candidates[0], legacyIndexes: [] }
    : { index: -1, legacyIndexes: [] };
}

function mergeCanonicalItem(existing, incoming, { mode, discoveredAt }) {
  const knownDiscovery = earliestIso([existing?.discoveredAt, incoming.discoveredAt]) || discoveredAt;
  const selected = normalizeFeedMode(mode) === 'selected'
    ? true
    : incoming.selectedPresent ? incoming.selected === true : existing?.selected === true;
  const { selectedPresent, ...serverFields } = incoming;
  return { ...existing, ...serverFields, discoveredAt: knownDiscovery, selected };
}

function mergeWatchStates(states, item, watchRules) {
  const valid = (states || []).filter(Boolean);
  if (valid.length === 0) return null;
  const firstMatchedAt = earliestIso(valid.map(state => state.firstMatchedAt));
  const viewedAt = earliestIso(valid.map(state => state.viewedAt));
  const notifyCount = Math.max(0, ...valid.map(state => Number(state.notifyCount || 0)));
  const lastNotifiedAt = latestIso(valid.map(state => state.lastNotifiedAt));
  const suppressedAt = earliestIso(valid.map(state => state.suppressedAt));
  return {
    ruleIds: matchWatchRules(item, watchRules).map(rule => rule.id),
    firstMatchedAt,
    viewedAt,
    notifyCount,
    lastNotifiedAt,
    ...(suppressedAt ? { suppressedAt } : {}),
    nextNotifyAt: viewedAt || suppressedAt ? '' : getNextWatchNotifyAt(firstMatchedAt, notifyCount, lastNotifiedAt)
  };
}

function getSafeCanonicalAliases(history, canonicalIndexes, item) {
  const canonicalIndexSet = new Set(canonicalIndexes);
  const aliases = new Set([item?.id, ...canonicalIndexes.flatMap(index => getItemAliases(history[index])), ...getItemAliases(item)].filter(Boolean));
  return Array.from(aliases).filter(alias => {
    if (alias === item?.id) return true;
    return !history.some((candidate, index) =>
      !canonicalIndexSet.has(index) && getItemAliases(candidate).includes(alias));
  });
}

function coalesceApiItems(items) {
  const coalesced = [];
  const indexById = new Map();
  (items || []).forEach(item => {
    if (item?.id && indexById.has(item.id)) {
      coalesced[indexById.get(item.id)] = item;
      return;
    }
    if (item?.id) indexById.set(item.id, coalesced.length);
    coalesced.push(item);
  });
  return coalesced;
}

function upsertCanonicalItems(state, items, options = {}) {
  const mode = normalizeFeedMode(options.mode);
  const discoveredAt = options.discoveredAt || new Date().toISOString();
  const matchedAt = options.matchedAt || (typeof discoveredAt === 'string' ? discoveredAt : new Date().toISOString());
  const historyDays = normalizeHistoryDays(options.historyDays);
  const displayCutoff = Date.now() - historyDays * 24 * 60 * 60 * 1000;
  const history = [...(state.history || [])];
  const readIds = new Set(state.readIds || []);
  const watchRules = state.watchRules || [];
  const watchNotifyState = { ...(state.watchNotifyState || {}) };
  const inserted = [];
  const updated = [];
  const newlyMatched = [];
  const insertedIndexByKey = new Map();
  const returnedCanonicalByKey = new Map();

  coalesceApiItems(items).forEach(item => {
    const match = findCanonicalMatch(history, item);
    const isInserted = match.index < 0;
    const canonicalIndexes = isInserted ? [] : [match.index, ...match.legacyIndexes];
    const existing = isInserted ? null : history[match.index];
    const absorbed = canonicalIndexes.map(index => history[index]).filter(Boolean);
    const itemDiscoveredAt = typeof discoveredAt === 'function' ? discoveredAt(item) : discoveredAt;
    const watchMatches = matchWatchRules(item, watchRules);
    const incomingEntry = {
      ...toHistoryEntry(item, itemDiscoveredAt, watchMatches, matchedAt),
      selectedPresent: item.selectedPresent
    };
    const existingForMerge = existing
      ? { ...existing, discoveredAt: earliestIso(absorbed.map(candidate => candidate.discoveredAt)) || existing.discoveredAt }
      : null;
    const canonical = mergeCanonicalItem(existingForMerge, incomingEntry, { mode, discoveredAt: itemDiscoveredAt });
    if (watchMatches.length === 0) {
      delete canonical.watchMatched;
      delete canonical.watchRuleIds;
      delete canonical.watchMatchedAt;
    }
    const priorMatchIds = new Set(existing?.watchRuleIds || []);
    const isNewlyMatched = !isInserted && watchMatches.length > 0 && watchMatches.some(rule => !priorMatchIds.has(rule.id));
    const safeAliases = getSafeCanonicalAliases(history, canonicalIndexes, canonical);
    const priorWatchStates = safeAliases.map(alias => watchNotifyState[alias]).filter(Boolean);
    const canonicalKey = getItemStateKey(canonical);

    if (priorWatchStates.length > 0) {
      watchNotifyState[canonicalKey] = mergeWatchStates(priorWatchStates, canonical, watchRules);
    } else if (isInserted && watchMatches.length > 0) {
      const state = buildWatchStateForItem(null, canonical, watchMatches.map(rule => rule.id), matchedAt);
      // Out-of-window items must not notify later when the user widens historyDays.
      watchNotifyState[canonicalKey] = isWithinDisplayWindow(canonical, displayCutoff)
        ? state
        : { ...state, nextNotifyAt: '', suppressedAt: matchedAt };
    }

    if (canonical.id && safeAliases.some(alias => readIds.has(alias))) readIds.add(canonical.id);
    safeAliases.forEach(alias => {
      if (alias !== canonicalKey) delete watchNotifyState[alias];
    });

    if (isInserted) {
      history.push(canonical);
      insertedIndexByKey.set(canonicalKey, inserted.length);
      inserted.push(canonical);
    } else {
      history[match.index] = canonical;
      [...match.legacyIndexes].sort((a, b) => b - a).forEach(index => history.splice(index, 1));
      if (insertedIndexByKey.has(canonicalKey)) {
        inserted[insertedIndexByKey.get(canonicalKey)] = canonical;
      } else if (isNewlyMatched) {
        newlyMatched.push(canonical);
      } else {
        updated.push(canonical);
      }
    }
    returnedCanonicalByKey.set(canonicalKey, canonical);
  });

  const returnedCanonicalItems = Array.from(returnedCanonicalByKey.values());

  if (mode === 'selected' && options.completeSelectedSnapshot === true) {
    const returnedIds = new Set(returnedCanonicalItems.map(item => item.id).filter(Boolean));
    history.forEach(item => {
      if (item.id && !returnedIds.has(item.id)) item.selected = false;
    });
  }

  // Cache the widest selectable window so reducing historyDays does not discard
  // items that should reappear when the user expands the display window.
  const cutoff = Date.now() - MAX_HISTORY_DAYS * 24 * 60 * 60 * 1000;
  const retainedHistory = history
    .filter(item => isWithinHistoryWindow(item, cutoff))
    .sort((a, b) => getItemTime(b) - getItemTime(a));
  const retainedWatchNotifyState = options.retainUnmatchedWatchState
    ? watchNotifyState
    : pruneWatchNotifyState(retainedHistory, watchNotifyState);
  const bounded = boundCanonicalStorageState({
    history: retainedHistory,
    readIds: Array.from(readIds),
    watchNotifyState: retainedWatchNotifyState,
    lastItems: inserted,
    retainUnmatchedWatchState: options.retainUnmatchedWatchState === true
  });
  const retainedAliases = new Set(bounded.history.flatMap(item => getItemAliases(item)));
  const retainedInserted = inserted.filter(item => getItemAliases(item).some(alias => retainedAliases.has(alias)));

  return {
    history: bounded.history,
    readIds: bounded.readIds,
    watchNotifyState: bounded.watchNotifyState,
    inserted: retainedInserted,
    updated: updated.filter(item => getItemAliases(item).some(alias => retainedAliases.has(alias))),
    newlyMatched: newlyMatched.filter(item => getItemAliases(item).some(alias => retainedAliases.has(alias)))
  };
}

function pruneWatchNotifyState(history, watchNotifyState) {
  const retainedAliases = new Set((history || []).flatMap(item => getItemAliases(item)));
  return Object.fromEntries(Object.entries(watchNotifyState || {})
    .filter(([key]) => retainedAliases.has(key)));
}

async function getPrunedStoredWatchNotifyState() {
  const { history = [], watchNotifyState = {} } = await chrome.storage.local.get(['history', 'watchNotifyState']);
  return pruneWatchNotifyState(history, watchNotifyState);
}

function getNormalizedItemTime(item) {
  return normalizeTimestamp(item.publishedAt) || normalizeTimestamp(item.sourceDiscoveredAt) || normalizeTimestamp(item.indexedAt);
}

function getCycleWatchNotificationBudget(used = 0) {
  if (!Number.isFinite(used)) return 0;
  return Math.max(MAX_WATCH_NOTIFICATIONS_PER_CYCLE - Math.max(0, Math.floor(used)), 0);
}

async function clearNotificationUrlOnClosed(notificationId) {
  if (notificationId && notificationId.startsWith('aihot-')) {
    await forgetNotificationUrl(notificationId);
  }
}

if (chrome.notifications.onClosed && chrome.notifications.onClosed.addListener) {
  chrome.notifications.onClosed.addListener((notificationId) => {
    return runMigratedStateMutation(() => clearNotificationUrlOnClosed(notificationId))
      .catch(e => console.warn('[AI HOT] failed to forget closed notification:', e));
  });
}


function getReadAllBefore(data) {
  return [data.readAllBefore, ...Object.values(data.readAllBeforeByMode || {})]
    .filter(value => value && Number.isFinite(new Date(value).getTime()))
    .reduce((latest, value) => !latest || new Date(value) > new Date(latest) ? value : latest, '');
}

async function advanceReadAllBefore(candidate = '', markWatchViewed = false) {
  const data = await chrome.storage.local.get(['readAllBefore', 'readAllBeforeByMode', 'watchNotifyState']);
  const readAllBefore = getReadAllBefore({
    ...data,
    readAllBeforeByMode: {
      ...(data.readAllBeforeByMode || {}),
      candidate
    }
  });
  const updates = {};
  if (readAllBefore !== (data.readAllBefore || '') || Object.keys(data.readAllBeforeByMode || {}).length > 0) {
    updates.readAllBefore = readAllBefore;
    updates.readAllBeforeByMode = {};
  }

  if (markWatchViewed) {
    const watchNotifyState = { ...(data.watchNotifyState || {}) };
    const candidateTime = new Date(candidate).getTime();
    Object.keys(watchNotifyState).forEach(alias => {
      const firstMatchedTime = new Date(watchNotifyState[alias].firstMatchedAt || 0).getTime();
      if (firstMatchedTime > candidateTime) return;
      watchNotifyState[alias] = { ...watchNotifyState[alias], viewedAt: watchNotifyState[alias].viewedAt || candidate };
    });
    updates.watchNotifyState = watchNotifyState;
  }

  if (Object.keys(updates).length > 0) await chrome.storage.local.set(updates);
  return readAllBefore;
}

function getItemTime(item) {
  return new Date(item.time || item.discoveredAt || 0).getTime();
}

function getUnreadReferenceTime(item) {
  const itemTime = getItemTime(item);
  const discoveredAt = new Date(item.discoveredAt || item.time).getTime();
  // A future publication time cannot make an item newer than its discovery.
  const cappedItemTime = Number.isFinite(discoveredAt) && Number.isFinite(itemTime)
    ? Math.min(itemTime, discoveredAt)
    : itemTime;
  return Math.max(
    Number.isFinite(cappedItemTime) ? cappedItemTime : 0,
    Number.isFinite(discoveredAt) ? discoveredAt : 0
  );
}

function isWithinHistoryWindow(item, cutoff) {
  return getUnreadReferenceTime(item) > cutoff;
}

function isWithinDisplayWindow(item, cutoff) {
  const publishedAt = new Date(item?.time || 0).getTime();
  return Number.isFinite(publishedAt) && publishedAt > cutoff;
}

function buildDiscoveryDelta(inserted, {
  historyDays = DEFAULT_HISTORY_DAYS,
  readIds = [],
  readAllBefore = '',
  readAllBeforeByMode = {}
} = {}) {
  const cutoff = Date.now() - normalizeHistoryDays(historyDays) * 24 * 60 * 60 * 1000;
  const readIdSet = new Set(Array.isArray(readIds) ? readIds : []);
  const readAllBeforeTime = new Date(getReadAllBefore({ readAllBefore, readAllBeforeByMode })).getTime();
  const visibleInserted = inserted.filter(item => isWithinDisplayWindow(item, cutoff));
  const visibleUnreadInserted = visibleInserted.filter(item => {
    if (getItemAliases(item).some(alias => readIdSet.has(alias))) return false;
    return !Number.isFinite(readAllBeforeTime) || getUnreadReferenceTime(item) > readAllBeforeTime;
  });
  return {
    inserted,
    visibleInserted,
    visibleUnreadInserted,
    watchInserted: visibleInserted.filter(item => item.watchMatched === true),
    normalInserted: inserted.filter(item => item.watchMatched !== true),
    normalVisibleUnreadInserted: visibleUnreadInserted.filter(item => item.watchMatched !== true)
  };
}

function toHistoryEntry(item, discoveredAt, watchMatches = [], watchMatchedAt = discoveredAt) {
  const normalizedTime = getNormalizedItemTime(item, discoveredAt);
  const entry = {
    title: item.title,
    id: item.id || '',
    titleEn: item.titleEn || item.title_en || item.originalTitle || '',
    url: getItemOpenUrl(item),
    permalink: item.permalink || item.url || '',
    source: item.source || '',
    category: item.category || '',
    summary: item.summary || '',
    score: item.score ?? null,
    selected: item.selected === true,
    attribution: item.attribution || null,
    sourceDiscoveredAt: normalizeTimestamp(item.sourceDiscoveredAt),
    time: normalizedTime,
    discoveredAt
  };
  if (watchMatches.length > 0) {
    entry.watchMatched = true;
    entry.watchRuleIds = watchMatches.map(rule => rule.id);
    entry.watchMatchedAt = watchMatchedAt;
  }
  return entry;
}

async function migrateReadAllBefore() {
  await advanceReadAllBefore();
}

async function pollForUpdatesInternal(watchCycle) {
  const config = await getConfig();
  if (!config.enabled) return;

  const notificationCycle = { sent: 0 };
  await runPostCommitSideEffect('pending notification retry', () => flushPendingNotifications(notificationCycle));

  const { nextAllowedPollAt = '', lastItemsPollAt = '', allFeedContinuation = {} } = await chrome.storage.local.get(['nextAllowedPollAt', 'lastItemsPollAt', 'allFeedContinuation']);
  if (nextAllowedPollAt && new Date(nextAllowedPollAt).getTime() > Date.now()) {
    console.log(`[AI HOT] polling paused until ${nextAllowedPollAt}`);
    return;
  }

  const now = new Date().toISOString();

  try {
    const fingerprintProbe = await probeItemsEtag(config.feedMode);
    if (!fingerprintProbe.ok) {
      console.warn(`[AI HOT] fingerprint returned ${fingerprintProbe.status}`);
      await recordApiFailure(fingerprintProbe.response || fingerprintProbe.status);
      return;
    }
    const safetyPollDue = isSafetyItemsPollDue(lastItemsPollAt);
    const sinceTime = getAutoPollSinceTime(config, safetyPollDue, lastItemsPollAt);
    console.log(`[AI HOT] polling since=${sinceTime}`);
    if (!fingerprintProbe.changed && !safetyPollDue) {
      await saveFingerprintProbe(fingerprintProbe);
      await chrome.storage.local.set({ lastCheck: now, failCount: 0, nextAllowedPollAt: '' });
      await runPostCommitSideEffect('poll skip badge update', updateBadge);
      console.log('[AI HOT] fingerprint unchanged, skip items');
      return;
    }

    const cutoff = Date.now() - MAX_HISTORY_DAYS * 24 * 60 * 60 * 1000;
    const allItems = await fetchItems({ mode: config.feedMode, sinceTime, cutoff, bypassEtag: safetyPollDue });
    if (allItems.notModified) {
      await chrome.storage.local.set({ lastCheck: now, failCount: 0, nextAllowedPollAt: '' });
      await runPostCommitSideEffect('poll 304 badge update', updateBadge);
      return { notModified: true };
    }
    fingerprintProbe.etag = allItems.etag;
    fingerprintProbe.etagUrl = getApiUrl(config.feedMode);
    const continuation = config.feedMode === 'all' && allFeedContinuation.active !== true && allItems.truncated && allItems.nextCursor
      ? { continuationId: getContinuationId(), cursor: allItems.nextCursor }
      : null;
    const persisted = await persistFetchedItems(allItems, {
      notify: true,
      watchCycle,
      notificationCycle,
      storageUpdates: continuation
        ? { allFeedContinuation: getActiveAllContinuationStatus(allItems.nextCursor, continuation.continuationId) }
        : undefined
    });
    console.log(`[AI HOT] got ${allItems.length} items`);

    if (!allItems.truncated) {
      await saveFingerprintProbe(fingerprintProbe);
      await commitSuccessfulItemsPoll({ now });
    } else {
      await chrome.storage.local.set({ lastCheck: now, failCount: 0, nextAllowedPollAt: '' });
      if (continuation) {
        await runPostCommitSideEffect('automatic all continuation alarm scheduling', () => chrome.alarms.create(ALL_CONTINUATION_ALARM_NAME, { when: Date.now() + RETRY_AFTER_FALLBACK_MS }));
      }
    }
    return { watchNotificationsSent: persisted.watchNotificationsSent, truncated: Boolean(allItems.truncated) };
  } catch (e) {
    console.error(`[AI HOT] fetch error:`, e);
    await recordApiFailure(e.response || e.status || 0);
    return { error: e };
  }
}

function pollForUpdates() {
  return runMigratedStateMutation(() => pollForUpdatesInternal());
}

async function incrementFailCount() {
  const { failCount = 0 } = await chrome.storage.local.get('failCount');
  const newCount = failCount + 1;
  await chrome.storage.local.set({ failCount: newCount });
  if (newCount >= 3) {
    await runPostCommitSideEffect('failure badge update', () => enqueueBadgeUpdate(async () => {
      await chrome.action.setBadgeText({ text: '!' });
      await chrome.action.setBadgeBackgroundColor({ color: '#F44336' });
    }));
  }
  return newCount;
}

function getCommittedEntries(items, history) {
  const byKey = new Map(history.map(item => [getItemStateKey(item), item]));
  return items.map(item => byKey.get(getItemStateKey(item))).filter(Boolean);
}

async function persistFetchedItems(items, options = {}) {
  const shouldNotify = options.notify === true;
  const watchNotificationLimit = Number.isFinite(options.watchNotificationLimit)
    ? options.watchNotificationLimit
    : MAX_WATCH_NOTIFICATIONS_PER_CYCLE;
  const discoveredAt = new Date().toISOString();
  const {
    history = [],
    historyDays = DEFAULT_HISTORY_DAYS,
    readIds = [],
    readAllBefore = '',
    readAllBeforeByMode = {},
    watchRules = [],
    watchNotifyState = {},
    allFeedContinuation = {},
    feedMode,
    watchOnly
  } = await chrome.storage.local.get(['history', 'historyDays', 'readIds', 'readAllBefore', 'readAllBeforeByMode', 'watchRules', 'watchNotifyState', 'allFeedContinuation', 'feedMode', 'watchOnly']);

  if (typeof options.isCurrent === 'function' && !await options.isCurrent()) {
    return { skipped: true, updated: history, newEntries: [], watchNotificationsSent: 0 };
  }

  const resolveDiscoveredAt = item => {
    const match = findCanonicalMatch(history, item);
    if (match.index >= 0) {
      return earliestIso([match.index, ...match.legacyIndexes]
        .map(index => history[index]?.discoveredAt)) || discoveredAt;
    }
    return getLegacyDiscoveredAtFallback(item, options.discoveredAtByAlias, discoveredAt);
  };
  const retainUnmatchedWatchState = options.retainUnmatchedWatchState === undefined
    ? normalizeFeedMode(feedMode) === 'all' && allFeedContinuation.active === true
    : options.retainUnmatchedWatchState === true;
  const persisted = upsertCanonicalItems({ history, readIds, watchRules, watchNotifyState }, items, {
    mode: feedMode,
    discoveredAt: resolveDiscoveredAt,
    matchedAt: discoveredAt,
    historyDays,
    retainUnmatchedWatchState
  });
  const orderedInserted = [
    ...persisted.inserted.filter(item => item.watchMatched === true),
    ...persisted.inserted.filter(item => item.watchMatched !== true)
  ];
  let committed = await persistCanonicalState({
    history: persisted.history,
    readIds: persisted.readIds,
    watchNotifyState: persisted.watchNotifyState,
    ...(options.updateLastItems !== false ? { lastItems: orderedInserted.slice(0, 5) } : {}),
    ...(options.storageUpdates || {})
  });
  const persistedWatchNotifyState = { ...committed.watchNotifyState };
  const inserted = getCommittedEntries(persisted.inserted, committed.history);
  const discoveryDelta = buildDiscoveryDelta(inserted, {
    historyDays,
    readIds: persisted.readIds || readIds,
    readAllBefore,
    readAllBeforeByMode
  });
  const watchItems = discoveryDelta.watchInserted;

  // The unread state is durable already; slow or failed notifications must not
  // delay its badge or determine whether the poll is considered successful.
  if (options.updateBadge !== false) await runPostCommitSideEffect('persist badge update', updateBadge);

  const notifiedWatchItems = shouldNotify
    ? await sendWatchNotifications(watchItems, persistedWatchNotifyState, discoveredAt, watchNotificationLimit, async () => {
      committed = await persistWatchNotificationProgress(committed, persistedWatchNotifyState);
    }, options.watchCycle)
    : [];
  const normalItems = discoveryDelta.normalInserted;
  const normalVisibleUnreadItems = discoveryDelta.normalVisibleUnreadInserted;

  // 只看特关时普通新内容不推送，特关通知照常。
  if (shouldNotify && watchOnly !== true && normalVisibleUnreadItems.length > 0) {
    const notificationItem = normalVisibleUnreadItems[0];
    const visibleUnreadCount = normalVisibleUnreadItems.length;
    const notifId = getNotificationId('aihot');
    await runPostCommitSideEffect('new-item notification', () => enqueueNotification(notifId, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: visibleUnreadCount > 1 ? `AI HOT 有 ${visibleUnreadCount} 条新内容` : 'AI HOT 新内容',
      message: notificationItem.title,
      contextMessage: notificationItem.source || ''
    }, getItemOpenUrl(notificationItem), visibleUnreadCount, options.notificationCycle));
  }

  return {
    updated: committed.history,
    newEntries: inserted,
    inserted,
    updatedEntries: getCommittedEntries(persisted.updated, committed.history),
    newlyMatched: getCommittedEntries(persisted.newlyMatched, committed.history),
    watchNotifyState: committed.watchNotifyState,
    watchNotificationsSent: notifiedWatchItems.length
  };
}

async function showNotification(items) {
  const result = await persistFetchedItems(items, { notify: true });
  return result.watchNotificationsSent;
}

async function checkWatchRemindersInternal(limit = MAX_WATCH_NOTIFICATIONS_PER_CYCLE, watchCycle) {
  if (limit <= 0) return 0;
  const { history = [], readIds = [], historyDays = DEFAULT_HISTORY_DAYS, feedMode, watchRules = [], watchNotifyState = {} } = await chrome.storage.local.get(['history', 'readIds', 'historyDays', 'feedMode', 'watchRules', 'watchNotifyState']);
  const cutoff = Date.now() - normalizeHistoryDays(historyDays) * 24 * 60 * 60 * 1000;
  const watchItems = projectHistory(history, feedMode)
    .filter(item => isWithinDisplayWindow(item, cutoff))
    .filter(item => getActiveWatchMatchIds(item, watchRules).length > 0 && findWatchState(watchNotifyState, item).state);
  if (watchItems.length === 0) return;
  const now = new Date().toISOString();
  const nextWatchNotifyState = { ...watchNotifyState };
  let committed = { history, readIds };
  const notified = await sendWatchNotifications(watchItems, nextWatchNotifyState, now, limit, async sent => {
    committed = await persistWatchNotificationProgress(committed, nextWatchNotifyState, sent);
  }, watchCycle);
  return notified.length;
}

function checkWatchReminders(limit = MAX_WATCH_NOTIFICATIONS_PER_CYCLE) {
  return runMigratedStateMutation(() => checkWatchRemindersInternal(limit));
}

async function manualPollInternal() {
  await assertNotInBackoff();
  const {
    history = [],
    historyDays = DEFAULT_HISTORY_DAYS,
    readIds = [],
    feedMode,
    lastCheck = '',
    lastItemsPollAt = '',
    watchRules = [],
    watchNotifyState = {},
    allFeedContinuation = {}
  } = await chrome.storage.local.get(['history', 'historyDays', 'readIds', 'feedMode', 'lastCheck', 'lastItemsPollAt', 'watchRules', 'watchNotifyState', 'allFeedContinuation']);
  const mode = normalizeFeedMode(feedMode);
  const now = new Date().toISOString();

  try {
    const fingerprintProbe = await probeItemsEtag(mode);
    if (!fingerprintProbe.ok) {
      console.warn(`[AI HOT] manual fingerprint returned ${fingerprintProbe.status}`);
      throw Object.assign(new Error(`API returned ${fingerprintProbe.status}`), { response: fingerprintProbe.response, status: fingerprintProbe.status });
    }

    if (!fingerprintProbe.changed) {
      await saveFingerprintProbe(fingerprintProbe);
      await chrome.storage.local.set({ lastCheck: now, failCount: 0, nextAllowedPollAt: '' });
      await runPostCommitSideEffect('manual poll skip badge update', updateBadge);
      console.log('[AI HOT] manual fingerprint unchanged, skip items');
      return;
    }

    const safetyPollDue = isSafetyItemsPollDue(lastItemsPollAt);
    const sinceTime = getAutoPollSinceTime({ interval: DEFAULT_INTERVAL, lastCheck: lastCheck || now }, safetyPollDue, lastItemsPollAt);
    console.log(`[AI HOT] manual poll since=${sinceTime}`);
    const cutoff = Date.now() - Math.max(normalizeHistoryDays(historyDays), MAX_HISTORY_DAYS) * 24 * 60 * 60 * 1000;
    const allItems = await fetchItems({ mode, sinceTime, cutoff, maxPages: MANUAL_MAX_PAGES, bypassEtag: safetyPollDue });
    if (allItems.notModified) {
      await chrome.storage.local.set({ lastCheck: now, failCount: 0, nextAllowedPollAt: '' });
      await runPostCommitSideEffect('manual 304 badge update', updateBadge);
      return;
    }
    fingerprintProbe.etag = allItems.etag;
    fingerprintProbe.etagUrl = getApiUrl(mode);
    const discoveredAt = new Date().toISOString();
    const persisted = upsertCanonicalItems({ history, readIds, watchRules, watchNotifyState }, allItems, {
      mode,
      discoveredAt,
      matchedAt: discoveredAt,
      historyDays,
      retainUnmatchedWatchState: mode === 'all' && allFeedContinuation.active === true
    });
    const merged = persisted.history;
    await persistCanonicalState({
      history: persisted.history,
      readIds: persisted.readIds,
      watchNotifyState: persisted.watchNotifyState,
      lastItems: persisted.inserted.slice(0, 5)
    });
    if (allItems.truncated) {
      await chrome.storage.local.set({ lastCheck: new Date().toISOString(), failCount: 0, nextAllowedPollAt: '' });
    } else {
      await saveFingerprintProbe(fingerprintProbe);
      await commitSuccessfulItemsPoll();
    }
    await runPostCommitSideEffect('manual poll badge update', updateBadge);
    console.log(`[AI HOT] manual poll done, ${merged.length} total items (fetched ${allItems.length})`);
  } catch (e) {
    if (e.backoff) throw e;
    console.error(`[AI HOT] manual poll error:`, e);
    await recordApiFailure(e.response || e.status || 0);
    throw e;
  }
}

function manualPoll() {
  return runMigratedStateMutation(manualPollInternal);
}

function enqueueBadgeUpdate(task) {
  // This queue must remain independent of stateMutationQueue: its callers can
  // already hold the state queue while source-switch/continuation callers do not.
  const operation = badgeUpdateQueue.then(task, task);
  badgeUpdateQueue = operation.catch(() => {});
  return operation;
}

function updateBadge() {
  return enqueueBadgeUpdate(async () => {
    try {
      await updateBadgeInternal();
    } catch (_e) {
      // Retry once from current durable state, never from the failed snapshot.
      await updateBadgeInternal();
    }
  });
}

async function updateBadgeInternal() {
  const data = await chrome.storage.local.get(['history', 'readIds', 'readAllBefore', 'readAllBeforeByMode', 'historyDays', 'feedMode', 'watchOnly', 'watchRules']);
  const { history = [], readIds = [], historyDays = DEFAULT_HISTORY_DAYS, feedMode, watchOnly, watchRules = [] } = data;
  const readIdSet = new Set(readIds);
  const readAllBefore = getReadAllBefore(data);
  const cutoff = Date.now() - normalizeHistoryDays(historyDays) * 24 * 60 * 60 * 1000;
  const projectedHistory = projectHistory(history, feedMode);
  const activeWatchRules = watchOnly === true ? normalizeWatchRuleList(watchRules) : [];
  const unread = projectedHistory.filter(i => {
    if (!isWithinDisplayWindow(i, cutoff)) return false;
    // 只看特关：角标与弹窗列表使用同一匹配口径，只统计命中启用规则的条目。
    if (watchOnly === true && !hasActiveWatchMatch(i, activeWatchRules)) return false;
    if (getItemAliases(i).some(alias => readIdSet.has(alias))) return false;
    if (readAllBefore && getUnreadReferenceTime(i) <= new Date(readAllBefore).getTime()) return false;
    return true;
  }).length;
  await chrome.action.setBadgeText({ text: unread > 0 ? String(unread) : '' });
  await chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR });
}

async function runPostCommitSideEffect(label, effect) {
  try {
    await effect();
  } catch (e) {
    console.warn(`[AI HOT] ${label} failed after durable commit:`, e);
  }
}

async function isCurrentFeedModeGeneration(generation, mode) {
  if (generation !== null && generation !== undefined && generation !== feedModeGeneration) return false;
  const { feedMode } = await chrome.storage.local.get('feedMode');
  return (generation === null || generation === undefined || generation === feedModeGeneration) && normalizeFeedMode(feedMode) === normalizeFeedMode(mode);
}

function getContinuationId() {
  if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') return globalThis.crypto.randomUUID();
  return `${Date.now()}-${Math.random()}`;
}

function getActiveAllContinuationStatus(cursor, continuationId) {
  return {
    active: true,
    id: continuationId,
    cursor,
    retryAttempts: 0,
    retryAt: '',
    expiresAt: new Date(Date.now() + ALL_CONTINUATION_STATUS_TTL_MS).toISOString()
  };
}

function getSettledAllContinuationStatus(continuation, updates = {}) {
  const { discoveredAtByAlias, ...status } = continuation || {};
  return { ...status, ...updates };
}

async function recoverAllFeedContinuationStatus() {
  const { allFeedContinuation = {}, feedMode } = await chrome.storage.local.get(['allFeedContinuation', 'feedMode']);
  if (allFeedContinuation.active !== true) {
    if (Object.prototype.hasOwnProperty.call(allFeedContinuation, 'discoveredAtByAlias')) {
      await chrome.storage.local.set({ allFeedContinuation: getSettledAllContinuationStatus(allFeedContinuation) });
    }
    return;
  }
  if (normalizeFeedMode(feedMode) !== 'all' || !allFeedContinuation.id || !allFeedContinuation.cursor) {
    const watchNotifyState = await getPrunedStoredWatchNotifyState();
    await chrome.storage.local.set({ allFeedContinuation: getSettledAllContinuationStatus(allFeedContinuation, { active: false }), watchNotifyState });
    await chrome.alarms.clear(ALL_CONTINUATION_ALARM_NAME);
    return;
  }
  const retryAt = new Date(allFeedContinuation.retryAt || 0).getTime();
  try {
    await chrome.alarms.create(ALL_CONTINUATION_ALARM_NAME, { when: retryAt > Date.now() ? retryAt : Date.now() });
  } catch (e) {
    console.warn('[AI HOT] failed to recover all feed continuation alarm:', e);
    const watchNotifyState = await getPrunedStoredWatchNotifyState();
    await chrome.storage.local.set({ allFeedContinuation: getSettledAllContinuationStatus(allFeedContinuation, { active: false, retryAt: '' }), watchNotifyState });
    await chrome.alarms.clear(ALL_CONTINUATION_ALARM_NAME);
  }
}

function startFingerprintProbe(mode) {
  return probeItemsEtag(mode).catch(() => null);
}

function saveDeferredAllFingerprintProbe(generation, fingerprintProbe, continuationId = '') {
  void Promise.resolve(fingerprintProbe)
    .then(probe => runStateMutation(async () => {
      if (!probe || !await isCurrentFeedModeGeneration(generation, 'all')) return;
      if (continuationId) {
        const { allFeedContinuation = {} } = await chrome.storage.local.get('allFeedContinuation');
        if (allFeedContinuation.id !== continuationId) return;
      }
      await saveFingerprintProbe(probe);
    }))
    .catch(e => console.warn('[AI HOT] deferred fingerprint save failed:', e));
}

async function getActiveAllContinuation(generation, continuationId, expected = {}) {
  if (!await isCurrentFeedModeGeneration(generation, 'all')) return null;
  const { allFeedContinuation = {} } = await chrome.storage.local.get('allFeedContinuation');
  if (allFeedContinuation.active !== true || !allFeedContinuation.cursor || allFeedContinuation.id !== continuationId) return null;
  if (expected.cursor !== undefined && allFeedContinuation.cursor !== expected.cursor) return null;
  if (expected.retryAttempts !== undefined && Number(allFeedContinuation.retryAttempts || 0) !== Number(expected.retryAttempts || 0)) return null;
  if (expected.retryAt !== undefined && (allFeedContinuation.retryAt || '') !== (expected.retryAt || '')) return null;
  return allFeedContinuation;
}

async function commitAllContinuationMutation(generation, continuationId, expected, mutation) {
  return runStateMutation(async () => {
    const continuation = await getActiveAllContinuation(generation, continuationId, expected);
    if (!continuation) return { skipped: true };
    return mutation(continuation);
  });
}

async function scheduleAllContinuationRetry(generation, continuationId, expected, retryAfterMs) {
  const retryAt = Date.now() + retryAfterMs;
  const scheduled = {
    ...expected,
    retryAttempts: expected.retryAttempts + 1,
    retryAt: new Date(retryAt).toISOString()
  };
  let retryPersisted = false;
  try {
    const result = await commitAllContinuationMutation(generation, continuationId, expected, async continuation => {
      await chrome.storage.local.set({ allFeedContinuation: { ...continuation, retryAttempts: scheduled.retryAttempts, retryAt: scheduled.retryAt } });
      retryPersisted = true;
      await chrome.alarms.create(ALL_CONTINUATION_ALARM_NAME, { when: retryAt });
      return { scheduled: true };
    });
    return !result.skipped;
  } catch (e) {
    const rollbackExpected = retryPersisted ? scheduled : expected;
    await commitAllContinuationMutation(generation, continuationId, rollbackExpected, async continuation => {
      const watchNotifyState = await getPrunedStoredWatchNotifyState();
      await chrome.storage.local.set({ allFeedContinuation: getSettledAllContinuationStatus(continuation, { active: false, retryAt: '' }), watchNotifyState });
      await chrome.alarms.clear(ALL_CONTINUATION_ALARM_NAME);
    });
    throw e;
  }
}

async function continueAllFeedInternal({ generation, continuationId, cursor, retryAttempts = 0, retryAt = '', fingerprintProbe = null }) {
  let nextCursor = cursor;
  const seenCursors = new Set();

  try {
    for (let page = 1; page < ALL_MAX_PAGES && nextCursor; page++) {
      const expected = { cursor: nextCursor, retryAttempts, retryAt };
      if (!await getActiveAllContinuation(generation, continuationId, expected)) return;
      if (seenCursors.has(nextCursor)) throw new Error('Repeated API cursor');
      seenCursors.add(nextCursor);

      const url = `${getApiUrl('all')}&cursor=${encodeURIComponent(nextCursor)}`;
      const pageResult = await fetchItemsPage(url);
      if (pageResult.notModified) continue;
      const response = getV1Page(pageResult.json);
      if (!await getActiveAllContinuation(generation, continuationId, expected)) return;

      const items = response.items.map(normalizeV1Item).filter(Boolean);
      const persisted = await commitAllContinuationMutation(generation, continuationId, expected, async continuation => {
        const reachedPageLimit = response.hasMore && page === ALL_MAX_PAGES - 1;
        const terminal = !response.hasMore;
        const continuationStatus = terminal
          ? getSettledAllContinuationStatus(continuation, { active: false, retryAt: '' })
          : { ...continuation, cursor: response.nextCursor, retryAttempts: 0, retryAt: '' };
        return persistFetchedItems(items, {
          notify: false,
          updateLastItems: false,
          updateBadge: false,
          discoveredAtByAlias: continuation.discoveredAtByAlias,
          retainUnmatchedWatchState: false,
          isCurrent: () => getActiveAllContinuation(generation, continuationId, expected),
          storageUpdates: {
            allFeedContinuation: continuationStatus,
            ...(terminal ? {
              lastCheck: new Date().toISOString(),
              failCount: 0,
              nextAllowedPollAt: '',
              ...(!response.hasMore ? { lastItemsPollAt: new Date().toISOString() } : {})
            } : {})
          }
        });
      });
      if (persisted.skipped) return;

      const reachedPageLimit = response.hasMore && page === ALL_MAX_PAGES - 1;
      nextCursor = response.nextCursor;
      retryAttempts = 0;
      retryAt = '';
      await runPostCommitSideEffect('continuation badge update', updateBadge);
      if (!response.hasMore) {
        await runPostCommitSideEffect('continuation alarm cleanup', () => chrome.alarms.clear(ALL_CONTINUATION_ALARM_NAME));
        if (fingerprintProbe) saveDeferredAllFingerprintProbe(generation, fingerprintProbe, continuationId);
        return;
      }
      if (reachedPageLimit) {
        await runPostCommitSideEffect('continuation page-budget alarm scheduling', () => chrome.alarms.create(ALL_CONTINUATION_ALARM_NAME, { when: Date.now() + RETRY_AFTER_FALLBACK_MS }));
        return;
      }
    }

  } catch (e) {
    const expected = { cursor: nextCursor, retryAttempts, retryAt };
    if (!await getActiveAllContinuation(generation, continuationId, expected)) return;
    const status = e.status || e.response?.status;
    const hasRetryAfter = Boolean(getResponseHeader(e.response, 'Retry-After'));
    if (status === 429 && hasRetryAfter && retryAttempts < ALL_CONTINUATION_MAX_429_RETRIES) {
      await scheduleAllContinuationRetry(generation, continuationId, expected, getRetryAfterMs(e.response, 429));
      return;
    }
    console.error('[AI HOT] all feed continuation error:', e);
    await commitAllContinuationMutation(generation, continuationId, expected, async continuation => {
      await incrementFailCount();
      const watchNotifyState = await getPrunedStoredWatchNotifyState();
      await chrome.storage.local.set({ allFeedContinuation: getSettledAllContinuationStatus(continuation, { active: false, retryAt: '' }), watchNotifyState });
      await chrome.alarms.clear(ALL_CONTINUATION_ALARM_NAME);
    });
  }
}

function continueAllFeed(continuation) {
  void continueAllFeedInternal(continuation)
    .catch(e => console.error('[AI HOT] all feed continuation failed:', e));
}

async function resumeAllFeedContinuation() {
  const { allFeedContinuation = {}, feedMode } = await chrome.storage.local.get(['allFeedContinuation', 'feedMode']);
  if (normalizeFeedMode(feedMode) !== 'all' || allFeedContinuation.active !== true || !allFeedContinuation.id || !allFeedContinuation.cursor) {
    const watchNotifyState = await getPrunedStoredWatchNotifyState();
    await chrome.storage.local.set({ allFeedContinuation: getSettledAllContinuationStatus(allFeedContinuation, { active: false }), watchNotifyState });
    await chrome.alarms.clear(ALL_CONTINUATION_ALARM_NAME);
    return;
  }
  const retryAt = new Date(allFeedContinuation.retryAt || 0).getTime();
  if (retryAt > Date.now()) {
    try {
      await chrome.alarms.create(ALL_CONTINUATION_ALARM_NAME, { when: retryAt });
    } catch (e) {
      console.warn('[AI HOT] failed to resume all feed continuation alarm:', e);
      const watchNotifyState = await getPrunedStoredWatchNotifyState();
      await chrome.storage.local.set({ allFeedContinuation: getSettledAllContinuationStatus(allFeedContinuation, { active: false, retryAt: '' }), watchNotifyState });
      await chrome.alarms.clear(ALL_CONTINUATION_ALARM_NAME);
    }
    return;
  }
  continueAllFeed({
    generation: null,
    continuationId: allFeedContinuation.id,
    cursor: allFeedContinuation.cursor,
    retryAttempts: Number(allFeedContinuation.retryAttempts || 0),
    retryAt: allFeedContinuation.retryAt || ''
  });
}

function getSourceSwitchRollbackState(data) {
  return {
    history: data.history || [],
    readIds: data.readIds || [],
    lastItems: data.lastItems || [],
    watchNotifyState: data.watchNotifyState || {},
    feedMode: normalizeFeedMode(data.feedMode),
    allFeedContinuation: data.allFeedContinuation || { active: false },
    lastCheck: data.lastCheck || '',
    failCount: Number(data.failCount || 0),
    nextAllowedPollAt: data.nextAllowedPollAt || '',
    lastItemsPollAt: data.lastItemsPollAt || ''
  };
}

async function restoreStaleSourceSwitch(rollbackState) {
  let cause;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      await chrome.storage.local.set(rollbackState);
      return;
    } catch (e) {
      cause = e;
    }
  }
  const error = new Error('Failed to restore stale source switch');
  error.cause = cause;
  error.sourceSwitchCompensationFailed = true;
  throw error;
}

async function resetAndPollInternal(feedMode, generation, capabilities = {}) {
  await assertNotInBackoff();
  console.log(`[AI HOT] resetAndPoll feedMode=${feedMode}`);
  try {
    const { historyDays = DEFAULT_HISTORY_DAYS } = await chrome.storage.local.get('historyDays');
    const normalizedHistoryDays = normalizeHistoryDays(historyDays);
    const cutoff = Date.now() - Math.max(normalizedHistoryDays, MAX_HISTORY_DAYS) * 24 * 60 * 60 * 1000;
    const sinceTime = new Date(Date.now() - Math.max(normalizedHistoryDays, 1) * 24 * 60 * 60 * 1000).toISOString();
    const mode = normalizeFeedMode(feedMode);
    const allItems = await fetchItems({ mode, sinceTime, cutoff, maxPages: mode === 'all' ? 1 : getMaxPages(mode) });
    if (generation !== sourceSwitchGeneration) return { stale: true };
    const discoveredAt = new Date().toISOString();
    const hasContinuation = mode === 'all' && allItems.truncated && allItems.nextCursor;
    const fingerprintProbe = {
      ok: true,
      changed: true,
      etag: allItems.etag || '',
      etagUrl: getApiUrl(mode)
    };
    const committed = await runStateMutation(async () => {
      if (generation !== sourceSwitchGeneration) return { stale: true };
      const stored = await chrome.storage.local.get([...SOURCE_SWITCH_STORAGE_KEYS, 'historyDays', 'watchRules']);
      const {
        history: previousHistory = [],
        historyDays: committedHistoryDays = DEFAULT_HISTORY_DAYS,
        readIds = [],
        watchRules = [],
        watchNotifyState = {}
      } = stored;
      if (generation !== sourceSwitchGeneration) return { stale: true };
      const rollbackState = getSourceSwitchRollbackState(stored);

      const canonical = upsertCanonicalItems({ history: previousHistory, readIds, watchRules, watchNotifyState }, allItems, {
        mode,
        discoveredAt,
        matchedAt: discoveredAt,
        historyDays: normalizeHistoryDays(committedHistoryDays),
        completeSelectedSnapshot: isCompleteSelectedSnapshot(
          allItems,
          mode,
          capabilities.supportsConsistentSelectedSnapshot === true || SUPPORTS_CONSISTENT_SELECTED_SNAPSHOT
        )
      });
      const watchItems = canonical.inserted.filter(item => item.watchMatched === true);
      const normalItems = canonical.inserted.filter(item => item.watchMatched !== true);
      const nextGeneration = feedModeGeneration + 1;
      const continuationId = getContinuationId();
      const continuation = hasContinuation
        ? { generation: nextGeneration, continuationId, cursor: allItems.nextCursor, fingerprintProbe }
        : null;
      if (generation !== sourceSwitchGeneration) return { stale: true };
      await persistCanonicalState({
        history: canonical.history,
        readIds: canonical.readIds,
        lastItems: [...watchItems, ...normalItems].slice(0, 5),
        watchNotifyState: pruneWatchNotifyState(canonical.history, canonical.watchNotifyState),
        feedMode: mode,
        allFeedContinuation: continuation
          ? getActiveAllContinuationStatus(allItems.nextCursor, continuationId)
          : { active: false },
        lastCheck: new Date().toISOString(),
        failCount: 0,
        nextAllowedPollAt: '',
        ...(!allItems.notModified && !allItems.truncated ? { lastItemsPollAt: new Date().toISOString() } : {})
      });
      if (generation !== sourceSwitchGeneration) {
        await restoreStaleSourceSwitch(rollbackState);
        return { stale: true };
      }
      feedModeGeneration = nextGeneration;
      return { continuation, nextHistory: canonical.history, nextGeneration };
    });
    if (committed.stale) return committed;

    console.log(`[AI HOT] resetAndPoll done, ${committed.nextHistory.length} items from ${allItems.length} fetched`);
    await runPostCommitSideEffect('source-switch continuation alarm cleanup', () => chrome.alarms.clear(ALL_CONTINUATION_ALARM_NAME));
    if (committed.continuation) {
      await runPostCommitSideEffect('source-switch continuation alarm scheduling', () => chrome.alarms.create(ALL_CONTINUATION_ALARM_NAME, { when: Date.now() + RETRY_AFTER_FALLBACK_MS }));
      continueAllFeed(committed.continuation);
    } else if (mode === 'all') {
      saveDeferredAllFingerprintProbe(committed.nextGeneration, fingerprintProbe);
    } else if (!allItems.truncated) {
      void Promise.resolve(fingerprintProbe)
        .then(probe => runStateMutation(async () => {
          if (generation !== sourceSwitchGeneration) return;
          const { feedMode: committedMode } = await chrome.storage.local.get('feedMode');
          if (normalizeFeedMode(committedMode) !== mode) return;
          await saveFingerprintProbe(probe);
        }))
        .catch(e => console.warn('[AI HOT] deferred fingerprint save failed:', e));
    }
    await runPostCommitSideEffect('source-switch badge update', updateBadge);
    return { stale: false };
  } catch (e) {
    if (e.sourceSwitchCompensationFailed) throw e;
    if (generation !== sourceSwitchGeneration) return { stale: true };
    if (e.backoff) throw e;
    console.error(`[AI HOT] resetAndPoll error:`, e);
    await runStateMutation(() => recordApiFailure(e.response || e.status || 0));
    throw e;
  }
}

function resetAndPoll(feedMode) {
  const generation = ++sourceSwitchGeneration;
  return ensureCanonicalHistoryMigration()
    .then(() => resetAndPollInternal(feedMode, generation));
}

chrome.notifications.onClicked.addListener((notificationId) => runMigratedStateMutation(async () => {
  if (notificationId.startsWith('aihot-')) {
    const { lastItems = [], notificationUrlMap = {}, notificationStateKeyMap = {} } = await chrome.storage.local.get(['lastItems', 'notificationUrlMap', 'notificationStateKeyMap']);
    const url = getSafeHttpsUrl(notificationUrlMap[notificationId] || lastItems[0]?.url);
    if (url) {
      await chrome.tabs.create({ url });
      // Opening from a notification counts as reading, matching the popup.
      const stateKey = notificationStateKeyMap[notificationId];
      await markItemsRead([stateKey, url], { skipBadge: true });
      if (notificationId.startsWith('aihot-watch-')) {
        await markWatchViewed([stateKey, url], { skipBadge: true });
      }
      await runPostCommitSideEffect('notification click badge update', updateBadge);
      await forgetNotificationUrl(notificationId);
    }
  }
}).catch(e => console.warn('[AI HOT] notification click failed:', e)));

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALL_CONTINUATION_ALARM_NAME) {
    return runMigratedStateMutation(resumeAllFeedContinuation);
  }
  if (alarm.name === ALARM_NAME) {
    return runMigratedStateMutation(async () => {
      const watchCycle = { attempted: new Set(), sent: 0 };
      await pollForUpdatesInternal(watchCycle);
      return checkWatchRemindersInternal(getCycleWatchNotificationBudget(watchCycle.sent), watchCycle);
    });
  }
});

async function setupAlarm() {
  const config = await getConfig();
  await chrome.alarms.clear(ALARM_NAME);
  if (config.enabled) {
    chrome.alarms.create(ALARM_NAME, { delayInMinutes: 0.1, periodInMinutes: config.interval });
  }
}

async function handleInstalled(details) {
  console.log(`[AI HOT] extension ${details.reason}`);
  await migrateReadAllBefore();
  if (details.reason === 'install') {
    try {
      const {
        feedMode,
        historyDays = DEFAULT_HISTORY_DAYS,
        history = [],
        readIds = [],
        watchRules = [],
        watchNotifyState = {}
      } = await chrome.storage.local.get(['feedMode', 'historyDays', 'history', 'readIds', 'watchRules', 'watchNotifyState']);
      const mode = normalizeFeedMode(feedMode);
      const cutoff = Date.now() - Math.max(normalizeHistoryDays(historyDays), MAX_HISTORY_DAYS) * 24 * 60 * 60 * 1000;
      const allItems = await fetchItems({ mode, cutoff, maxPages: Math.min(getMaxPages(mode), SELECTED_MAX_PAGES) });
      const discoveredAt = new Date().toISOString();
      const canonical = upsertCanonicalItems({ history, readIds, watchRules, watchNotifyState }, allItems, {
        mode,
        discoveredAt,
        matchedAt: discoveredAt,
        historyDays: normalizeHistoryDays(historyDays)
      });
      await chrome.storage.local.set({
        history: canonical.history,
        readIds: canonical.readIds,
        watchNotifyState: canonical.watchNotifyState
      });
    } catch (e) {
      console.warn('[AI HOT] failed to fetch initial items:', e);
    }
  }
  await chrome.storage.local.set({ lastCheck: new Date().toISOString() });
  await updateBadge();
  await setupAlarm();
}

chrome.runtime.onInstalled.addListener((details) => runMigratedStateMutation(() => handleInstalled(details)));

chrome.runtime.onStartup.addListener(() => runMigratedStateMutation(async () => {
  await migrateReadAllBefore();
  await runPostCommitSideEffect('startup badge update', updateBadge);
  await recoverAllFeedContinuationStatus();
  await setupAlarm();
}));

void runMigratedStateMutation(recoverAllFeedContinuationStatus)
  .catch(e => console.warn('[AI HOT] failed to initialize canonical history:', e));

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'openItem') {
    openItem(msg.url, msg.ids || msg.urls || msg.id)
      .then(result => sendResponse(result))
      .catch((e) => sendResponse({ ok: false, reason: 'tab-create-failed', error: e.message }));
    return true;
  }
  if (msg.type === 'configChanged') {
    runMigratedStateMutation(setupAlarm)
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'pollNow') {
    manualPoll()
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'feedModeChanged') {
    resetAndPoll(msg.feedMode)
      .then(result => sendResponse(result?.stale ? { ok: false, stale: true } : { ok: true }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'markWatchViewed') {
    runMigratedStateMutation(() => markWatchViewed(msg.urls || msg.url))
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'markItemsRead') {
    runMigratedStateMutation(() => markItemsRead(msg.ids || msg.urls || msg.id || msg.url))
      .then(readIds => sendResponse({ ok: true, readIds }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'saveWatchRules') {
    runMigratedStateMutation(() => saveWatchRules(msg.watchRules || msg.rules))
      .then(watchRules => sendResponse({ ok: true, watchRules }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'markAllRead') {
    runMigratedStateMutation(async () => {
      if (!msg.readAllBefore || !Number.isFinite(new Date(msg.readAllBefore).getTime())) throw new Error('Invalid readAllBefore');
      if (msg.scope === 'watch') {
        await markWatchItemsReadBefore(msg.readAllBefore);
        await runPostCommitSideEffect('mark-watch-read badge update', updateBadge);
        return '';
      }
      const readAllBefore = await advanceReadAllBefore(msg.readAllBefore, true);
      await runPostCommitSideEffect('mark-all-read badge update', updateBadge);
      return readAllBefore;
    })
      .then(readAllBefore => sendResponse({ ok: true, readAllBefore }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

// 数据变化时自动更新 badge
chrome.storage.onChanged.addListener((changes) => {
  if (changes.history || changes.readIds || changes.readAllBefore || changes.readAllBeforeByMode || changes.feedMode || changes.historyDays || changes.watchOnly || changes.watchRules) {
    runMigratedStateMutation(updateBadge)
      .catch(e => console.warn('[AI HOT] failed to update badge:', e));
  }
});

if (typeof module === 'object' && module.exports) {
  module.exports = {
    isCompleteSelectedSnapshot,
    migrateCanonicalHistoryState,
    boundCanonicalStorageState,
    persistCanonicalState,
    resetAndPollForTest(feedMode, capabilities = {}) {
      const generation = ++sourceSwitchGeneration;
      return ensureCanonicalHistoryMigration()
        .then(() => resetAndPollInternal(feedMode, generation, capabilities));
    }
  };
}
