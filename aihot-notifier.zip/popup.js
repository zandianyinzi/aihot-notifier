const enabledEl = document.getElementById('enabled');
const perfLog = window.__popupPerfLog || function () {};
perfLog('js-start');

new ResizeObserver(entries => {
  const r = entries[0].contentRect;
  perfLog('resize', { width: Math.round(r.width), height: Math.round(r.height) });
}).observe(document.documentElement);

new PerformanceObserver(list => {
  list.getEntries().forEach(e => perfLog('paint', {
    name: e.name,
    startTime: Number(e.startTime.toFixed(2))
  }));
}).observe({ type: 'paint', buffered: true });
const intervalEl = document.getElementById('interval');
const feedModeEl = document.getElementById('feedMode');
const themeEl = document.getElementById('theme');
const fontFamilyEl = document.getElementById('fontFamily');
const fontSizeEl = document.getElementById('fontSize');
const openPositionModeEl = document.getElementById('openPositionMode');
const historyDaysEl = document.getElementById('historyDays');
const jumpToUnreadBtn = document.getElementById('jumpToUnread');
const markAllReadBtn = document.getElementById('markAllRead');
const scrollToTopBtn = document.getElementById('scrollToTop');
const scrollToBottomBtn = document.getElementById('scrollToBottom');
const pollBtn = document.getElementById('pollNow');
const settingsBtn = document.getElementById('settingsBtn');
const settingsPanel = document.getElementById('settingsPanel');
const settingsInnerEl = settingsPanel.querySelector('.settings-inner');
const historyList = document.getElementById('historyList');
const watchRulesList = document.getElementById('watchRulesList');
const watchSourceEl = document.getElementById('watchSource');
const watchAuthorEl = document.getElementById('watchAuthor');
const watchKeywordsEl = document.getElementById('watchKeywords');
const addWatchRuleBtn = document.getElementById('addWatchRule');
const popupStatusEl = document.getElementById('popupStatus');
const popupReliability = window.PopupReliability;
const { normalizeFeedMode, projectHistory } = window.FeedState;
const { getSafeHttpsUrl, openHttpsUrl, runOpenItemMutation, removeOptimisticReadAliases, createConfigMutationController, createFeedModeSwitchController, createLatestWinsLoadController, createPopupInitializationController, createPopupStorageChangeHandler, createAllFeedContinuationStatusController, createSessionWatchPinTracker, hasActiveWatchRuleMatch, moveWatchRule, captureWatchRuleActionFocus, restoreWatchRuleActionFocus, sortWatchItemsByRulePriority, buildHistoryRenderSignature, captureScrollAnchor, buildScrollPosition, restoreScrollAnchor, applyOptimisticReadState, runMarkAllReadMutation } = popupReliability;
const sessionWatchPinTracker = createSessionWatchPinTracker();

const CATEGORY_MAP = {
  'ai-models': { cls: 'cat-model', label: '模型' },
  'model': { cls: 'cat-model', label: '模型' },
  'ai-products': { cls: 'cat-products', label: '产品' },
  'industry': { cls: 'cat-industry', label: '行业' },
  'paper': { cls: 'cat-paper', label: '论文' },
  'tip': { cls: 'cat-tips', label: '技巧' },
  'tips': { cls: 'cat-tips', label: '技巧' }
};

const VALID_THEMES = new Set(['dark', 'green-dark', 'chrome-dark', 'slate-night']);
const DEFAULT_HISTORY_DAYS = 1;
const POPUP_CACHE_KEY = 'popupDataSnapshot';
const POPUP_SESSION_KEY = 'popupWarmSession';
const POPUP_SCROLL_KEY = 'popupScrollPosition';
const POPUP_CACHE_VERSION = 4;
const POPUP_CACHE_TTL_MS = 30 * 60 * 1000;
const POPUP_SCROLL_TTL_MS = 30 * 60 * 1000;
const POPUP_SCROLL_SAVE_DELAY_MS = 200;
const BUTTON_RESULT_CLASSES = ['is-result-accent', 'is-result-danger', 'is-result-ok'];
const BUTTON_TRANSIENT_CLASSES = ['is-loading', ...BUTTON_RESULT_CLASSES];
const BUTTON_RESULT_MIN_MS = 600;
const BUTTON_RESULT_MAX_MS = 1400;
const BUTTON_RESULT_TARGET_TOTAL_MS = 1800;
const VALID_FONTS = new Set(['system', 'noto-serif', 'lxgw']);
const VALID_OPEN_POSITION_MODES = new Set(['free', 'unread']);

let cachedReadIds = new Set();
let unreadJumpTimer = 0;
let lastRenderSignature = '';
let scrollSaveTimer = 0;
let scrollPersistenceSuppressed = false;
let cachedHistoryScrollHeight = 0;
let feedModeSwitchController = null;
let lastCommittedConfig = null;
const enqueuePopupMutation = popupReliability.createMutationQueue();

const popupStatusController = popupReliability.createPopupStatusController((message, kind) => {
  if (!popupStatusEl) return;
  popupStatusEl.textContent = message;
  popupStatusEl.classList.toggle('is-error', kind === 'error');
  popupStatusEl.classList.toggle('is-continuation', kind === 'continuation');
});

function showPopupStatus(message, options = {}) {
  popupStatusController.show(message, options);
}

const allFeedContinuationStatusController = createAllFeedContinuationStatusController({
  // Background continuation is intentionally silent; only actionable errors use the status bar.
  showStatus: () => {}
});

function clearButtonFeedback(button) {
  button.classList.remove(...BUTTON_TRANSIENT_CLASSES);
  button.style.removeProperty('--control-result-duration');
}

function waitForNextPaint() {
  return new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
}

function logPerf(phase, fields = {}) {
  perfLog(phase, fields);
}

let settingsTraceSequence = 0;
let activeSettingsTrace = null;

function beginSettingsTrace(nextOpen) {
  const trace = {
    id: ++settingsTraceSequence,
    nextOpen: Boolean(nextOpen),
    startedAt: performance.now()
  };
  activeSettingsTrace = trace;
  logPerf('settings-click', {
    id: trace.id,
    nextOpen: trace.nextOpen,
    historyChildren: historyList?.children.length || 0
  });

  function logFrame(frame) {
    requestAnimationFrame(() => {
      if (activeSettingsTrace !== trace) return;
      logPerf('settings-frame', {
        id: trace.id,
        frame,
        sinceClickMs: Number((performance.now() - trace.startedAt).toFixed(2))
      });
      if (frame < 2) logFrame(frame + 1);
    });
  }
  logFrame(1);
}

function measureSettingsLayoutRead(target, read) {
  const startedAt = performance.now();
  const result = read();
  if (activeSettingsTrace) {
    logPerf('settings-layout-read', {
      id: activeSettingsTrace.id,
      target,
      durationMs: Number((performance.now() - startedAt).toFixed(2)),
      ...result
    });
  }
  return result;
}

function getButtonResultDuration(elapsedMs) {
  if (!Number.isFinite(elapsedMs)) return BUTTON_RESULT_MAX_MS;
  return Math.round(Math.max(
    BUTTON_RESULT_MIN_MS,
    Math.min(BUTTON_RESULT_MAX_MS, BUTTON_RESULT_TARGET_TOTAL_MS - elapsedMs)
  ));
}

function removeClassAfterAnimation(button, className, onCleanup) {
  let cleaned = false;
  const cleanup = () => {
    if (cleaned) return;
    cleaned = true;
    button.classList.remove(className);
    if (onCleanup) onCleanup();
  };

  button.addEventListener('animationend', cleanup, { once: true });
  requestAnimationFrame(() => {
    if (getComputedStyle(button).animationName === 'none') cleanup();
  });
}

function showButtonResult(button, className, elapsedMs) {
  button.classList.remove(...BUTTON_TRANSIENT_CLASSES);
  button.style.setProperty('--control-result-duration', `${getButtonResultDuration(elapsedMs)}ms`);
  button.classList.add(className);
  removeClassAfterAnimation(button, className, () => {
    button.style.removeProperty('--control-result-duration');
    // Only hide mark-all-read button after animation if there are no unread items
    if (button.id === 'markAllRead') {
      const unreadItems = document.querySelectorAll('.item.unread');
      if (unreadItems.length === 0) {
        button.classList.remove('visible');
      }
    }
  });
}


function readPopupCache(expectedMode) {
  try {
    const raw = localStorage.getItem(POPUP_CACHE_KEY);
    if (!raw) return null;

    const cached = JSON.parse(raw);
    if (!cached || cached.version !== POPUP_CACHE_VERSION || !cached.data) return null;
    if (cached.extensionVersion !== chrome.runtime.getManifest().version) return null;
    if (!cached.cachedAt || Date.now() - cached.cachedAt > POPUP_CACHE_TTL_MS) return null;
    const feedMode = normalizeFeedMode(cached.data.feedMode);
    if (expectedMode !== undefined && feedMode !== normalizeFeedMode(expectedMode)) return null;
    return {
      ...cached.data,
      feedMode,
      history: projectHistory(cached.data.history || [], feedMode)
    };
  } catch (_e) {
    localStorage.removeItem(POPUP_CACHE_KEY);
    return null;
  }
}

async function readWarmPopupCache(expectedMode) {
  if (!chrome.storage.session) return null;

  try {
    const data = await chrome.storage.session.get(POPUP_SESSION_KEY);
    const session = data[POPUP_SESSION_KEY];
    if (!session || session.extensionVersion !== chrome.runtime.getManifest().version) return null;
    return readPopupCache(expectedMode);
  } catch (_e) {
    return null;
  }
}

async function markPopupSessionWarm() {
  if (!chrome.storage.session) return;

  try {
    await chrome.storage.session.set({
      [POPUP_SESSION_KEY]: {
        extensionVersion: chrome.runtime.getManifest().version,
        warmedAt: Date.now()
      }
    });
  } catch (_e) {
    // Session cache is an optimization only.
  }
}

function writePopupCache(partialData) {
  try {
    const previous = readPopupCache() || {};
    const nextMode = normalizeFeedMode(partialData.feedMode === undefined ? previous.feedMode : partialData.feedMode);
    const data = {
      ...previous,
      ...partialData,
      feedMode: nextMode
    };
    if (Array.isArray(data.history)) data.history = projectHistory(data.history, nextMode);
    if (previous.feedMode && previous.feedMode !== nextMode && !Object.prototype.hasOwnProperty.call(partialData, 'history')) {
      delete data.history;
    }
    localStorage.setItem(POPUP_CACHE_KEY, JSON.stringify({
      version: POPUP_CACHE_VERSION,
      extensionVersion: chrome.runtime.getManifest().version,
      cachedAt: Date.now(),
      data
    }));
  } catch (_e) {
    // Keep popup rendering fast even if localStorage is full or unavailable.
  }
}

function formatDateTime(isoStr) {
  const d = new Date(isoStr || Date.now());
  if (!Number.isFinite(d.getTime())) return '';
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  return `${month}/${day} ${hours}:${minutes}`;
}


function splitWatchKeywords(value) {
  if (Array.isArray(value)) return value.flatMap(v => splitWatchKeywords(v)).filter(Boolean);
  return String(value || '').split(/[,，]/).map(v => v.trim()).filter(Boolean);
}

function normalizeText(value) {
  return String(value || '').trim().toLowerCase();
}

function normalizeWatchRules(rules) {
  if (!Array.isArray(rules)) return [];
  return rules.map((rule, index) => ({
    id: String(rule.id || `wr_${index}`),
    source: String(rule.source || '').trim(),
    author: String(rule.author || '').trim(),
    keywords: splitWatchKeywords(rule.keywords),
    enabled: rule.enabled !== false,
    createdAt: rule.createdAt || ''
  }));
}

function getWatchRuleLabel(rule) {
  const sourceText = rule.source ? `来源：${rule.source}` : '来源不限';
  const authorText = rule.author ? `作者：${rule.author}` : '作者不限';
  const keywordText = rule.keywords.length > 0 ? `关键词：${rule.keywords.join('、')}` : '关键词不限';
  return [sourceText, authorText, keywordText].join('；');
}

function mergeWatchRuleInput(rules, input) {
  const normalized = normalizeWatchRules(rules);
  const source = String(input.source || '').trim();
  const author = String(input.author || '').trim();
  const keywords = splitWatchKeywords(input.keywords);
  if (!source && !author && keywords.length === 0) return normalized;
  const sameRule = normalized.find(rule => normalizeText(rule.source) === normalizeText(source) && normalizeText(rule.author) === normalizeText(author));
  if (!sameRule) {
    return [
      ...normalized,
      {
        id: `wr_${Date.now()}`,
        source,
        author,
        keywords,
        enabled: true,
        createdAt: new Date().toISOString()
      }
    ];
  }
  const mergedKeywords = [...sameRule.keywords];
  for (const keyword of keywords) {
    if (!mergedKeywords.some(existing => normalizeText(existing) === normalizeText(keyword))) mergedKeywords.push(keyword);
  }
  return normalized.map(rule => rule.id === sameRule.id ? { ...rule, keywords: mergedKeywords } : rule);
}

function removeWatchRuleKeyword(rules, ruleId, keywordIndex) {
  return normalizeWatchRules(rules)
    .map(rule => rule.id === ruleId ? { ...rule, keywords: rule.keywords.filter((_, index) => index !== keywordIndex) } : rule)
    .filter(rule => rule.source || rule.author || rule.keywords.length > 0);
}

function updateWatchRulesScrollHint() {
  if (!watchRulesList) return;
  const hasScrollTail = watchRulesList.scrollHeight - watchRulesList.scrollTop - watchRulesList.clientHeight > 1;
  watchRulesList.classList.toggle('has-scroll-tail', hasScrollTail);
}

function updateSettingsScrollHint() {
  if (!settingsInnerEl) return;
  const metrics = measureSettingsLayoutRead('settings-inner', () => ({
    scrollHeight: settingsInnerEl.scrollHeight,
    scrollTop: settingsInnerEl.scrollTop,
    clientHeight: settingsInnerEl.clientHeight
  }));
  const hasScrollTail = metrics.scrollHeight - metrics.scrollTop - metrics.clientHeight > 1;
  settingsInnerEl.classList.toggle('has-scroll-tail', hasScrollTail);
}

function updateHistoryScrollControls(options = {}) {
  if (!historyList || !scrollToTopBtn || !scrollToBottomBtn) return;
  const metrics = measureSettingsLayoutRead('history-list', () => ({
    scrollHeight: options.readScrollHeight !== false || cachedHistoryScrollHeight <= 0
      ? historyList.scrollHeight
      : cachedHistoryScrollHeight,
    clientHeight: historyList.clientHeight,
    scrollTop: historyList.scrollTop
  }));
  if (options.readScrollHeight !== false || cachedHistoryScrollHeight <= 0) {
    cachedHistoryScrollHeight = metrics.scrollHeight;
  }
  const maxScrollTop = Math.max(metrics.scrollHeight - metrics.clientHeight, 0);
  const canScroll = maxScrollTop > 1;
  const scrollTop = Math.max(metrics.scrollTop, 0);
  scrollToTopBtn.classList.toggle('visible', canScroll && scrollTop > 1);
  scrollToBottomBtn.classList.toggle('visible', canScroll && maxScrollTop - scrollTop > 1);
}

function scrollHistoryTo(top) {
  // Large grouped histories can expose compositor repaint gaps during smooth
  // scrolling; navigation buttons should jump directly to the requested edge.
  historyList.scrollTo({ top, behavior: 'auto' });
}

function renderWatchRules(rules, options = {}) {
  if (!watchRulesList) return;
  const capturedFocus = captureWatchRuleActionFocus(watchRulesList, document.activeElement);
  const normalized = normalizeWatchRules(rules);
  if (normalized.length === 0) {
    watchRulesList.innerHTML = '';
    updateWatchRulesScrollHint();
    return;
  }
  watchRulesList.innerHTML = normalized.map((rule, ruleIndex) => {
    const ruleLabel = escapeHtml(getWatchRuleLabel(rule));
    const toggleAction = rule.enabled ? '停用' : '启用';
    return `
    <div class="watch-rule-card ${rule.enabled ? '' : 'disabled'} ${rule.id === options.movedRuleId ? 'is-moved' : ''}" data-rule-id="${escapeHtml(rule.id)}">
      <div class="watch-rule-content" title="${escapeHtml(getWatchRuleLabel(rule))}">
        <div class="watch-rule-head">
          <span class="watch-rule-source">${escapeHtml(rule.source || '任意来源')}</span>
          <span class="watch-rule-author">${escapeHtml(rule.author || '任意作者')}</span>
          <div class="watch-rule-actions">
            <button class="btn-mini watch-rule-btn" data-action="toggle" title="${toggleAction}" aria-label="${toggleAction} ${ruleLabel}">${rule.enabled ? '停' : '启'}</button>
            <button class="btn-mini watch-rule-btn" data-action="delete" title="删除" aria-label="删除 ${ruleLabel}">×</button>
            <span class="watch-rule-move-group">
              <button class="btn-mini watch-rule-btn watch-rule-move" data-action="move-up" title="上移" aria-label="上移 ${ruleLabel}" ${ruleIndex === 0 ? 'disabled' : ''}>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 14 6-6 6 6"/></svg>
              </button>
              <button class="btn-mini watch-rule-btn watch-rule-move" data-action="move-down" title="下移" aria-label="下移 ${ruleLabel}" ${ruleIndex === normalized.length - 1 ? 'disabled' : ''}>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 10 6 6 6-6"/></svg>
              </button>
            </span>
          </div>
        </div>
        ${rule.keywords.length > 0 ? `<div class="watch-keyword-tags">${rule.keywords.map((keyword, index) => `<span class="watch-keyword-tag"><span class="watch-keyword-text">${escapeHtml(keyword)}</span><button class="watch-keyword-remove" data-keyword-index="${index}" title="删除关键词" aria-label="删除关键词 ${escapeHtml(keyword)}">×</button></span>`).join('')}</div>` : ''}
      </div>
    </div>
  `;
  }).join('');
  const focusRuleId = options.focusRuleId || capturedFocus?.ruleId;
  const focusAction = options.focusAction || capturedFocus?.action;
  if (focusRuleId && focusAction) {
    restoreWatchRuleActionFocus(watchRulesList, focusRuleId, focusAction);
  }
  updateWatchRulesScrollHint();
  requestAnimationFrame(updateSettingsScrollHint);
}

async function saveWatchRules(rules, options = {}) {
  const normalized = normalizeWatchRules(rules);
  const response = await chrome.runtime.sendMessage({ type: 'saveWatchRules', watchRules: normalized });
  if (!response?.ok) throw new Error(response?.error || 'Failed to save watch rules');
  renderWatchRules(normalized, options);
  if (options.scrollToEnd && watchRulesList) {
    watchRulesList.scrollTop = watchRulesList.scrollHeight;
  }
  updateWatchRulesScrollHint();
  requestAnimationFrame(updateSettingsScrollHint);
}

function renderItemHtml(item, isUnread, options = {}) {
  const cat = getCategory(item.category);
  const title = escapeHtml(item.title);
  const source = escapeHtml(item.source || '');
  const tagHtml = cat.label ? `<span class="cat-tag ${cat.cls}">${cat.label}</span>` : '';
  const watchTagHtml = item.watchMatched ? '<span class="watch-badge">特关</span>' : '';
  const summary = escapeHtml(item.summary || '');
  const summaryHtml = summary ? `<div class="item-summary">${summary}</div>` : '';
  const stateKey = getItemStateKey(item);
  const openUrl = getItemOpenUrl(item);
  return `<div class="item ${isUnread ? 'unread' : 'read'} ${item.watchMatched ? 'watch-item' : ''}" data-key="${escapeHtml(stateKey)}" data-url="${escapeHtml(openUrl)}"${options.watchPinned ? ' data-watch-pinned="true"' : ''} role="link" tabindex="0">
    <div class="item-body">
      <div class="item-title">${options.prefix || ''}${title}</div>
      ${summaryHtml}
      <div class="item-meta">
        ${watchTagHtml}
        ${tagHtml}
        <span class="item-source">${source}</span>
        <span class="sep"></span>
        <span class="item-datetime">${formatDateTime(item.time)}</span>
      </div>
    </div>
  </div>`;
}

async function markWatchUrlsViewed(urls) {
  const list = Array.isArray(urls) ? urls.filter(Boolean) : [urls].filter(Boolean);
  if (list.length === 0) return;
  try {
    const response = await chrome.runtime.sendMessage({ type: 'markWatchViewed', urls: list });
    if (!response?.ok) throw new Error(response?.error || 'Failed to mark watch items viewed');
  } catch (_e) {
    showPopupStatus('特关状态更新失败，请重试。');
  }
}

async function markWatchItemsViewed(items) {
  const keys = (items || []).flatMap(item => getItemAliases(item)).filter(Boolean);
  await markWatchUrlsViewed([...new Set(keys)]);
}

function getCategory(category) {
  if (!category) return { cls: 'cat-default', label: '' };
  if (CATEGORY_MAP[category]) return CATEGORY_MAP[category];
  return { cls: 'cat-default', label: '' };
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function getItemOpenUrl(item) {
  return getSafeHttpsUrl(item && (item.url || item.permalink || ''));
}

function getItemStateKey(item) {
  return item && (item.id || item.permalink || item.url || '');
}

function getItemAliases(item) {
  if (!item) return [];
  return [getItemStateKey(item), item.id, item.permalink, item.url]
    .filter(Boolean)
    .filter((value, index, arr) => arr.indexOf(value) === index);
}

function normalizeTheme(theme) {
  return VALID_THEMES.has(theme) ? theme : 'dark';
}

function normalizeFontFamily(font) {
  if (font === 'noto-sans') return 'system';
  return VALID_FONTS.has(font) ? font : 'system';
}

function normalizeOpenPositionMode(mode) {
  return VALID_OPEN_POSITION_MODES.has(mode) ? mode : 'free';
}

function getScrollContext(data) {
  return {
    feedMode: normalizeFeedMode(data.feedMode),
    historyDays: Number(data.historyDays || DEFAULT_HISTORY_DAYS)
  };
}

function getScrollDiagnostics(position = {}) {
  return {
    scrollTop: Number.isFinite(position.scrollTop) ? Math.round(position.scrollTop * 10) / 10 : null,
    anchorKey: String(position.anchorKey || '').slice(0, 120),
    anchorUrl: String(position.anchorUrl || '').slice(0, 120),
    offsetTop: Number.isFinite(position.offsetTop) ? Math.round(position.offsetTop * 10) / 10 : null,
    feedMode: position.feedMode || '',
    historyDays: Number(position.historyDays || 0)
  };
}

function readScrollPosition() {
  try {
    const raw = localStorage.getItem(POPUP_SCROLL_KEY);
    if (!raw) return null;
    const position = JSON.parse(raw);
    if (!position || !position.savedAt || Date.now() - position.savedAt > POPUP_SCROLL_TTL_MS) {
      localStorage.removeItem(POPUP_SCROLL_KEY);
      return null;
    }
    return position;
  } catch (_e) {
    localStorage.removeItem(POPUP_SCROLL_KEY);
    return null;
  }
}

function writeScrollPosition(data = {}, anchor = null) {
  if (normalizeOpenPositionMode(openPositionModeEl.value) !== 'free') return;
  const context = getScrollContext(data);
  const position = anchor
    ? { ...anchor, ...context, savedAt: Date.now() }
    : buildScrollPosition(historyList, context);
  try {
    localStorage.setItem(POPUP_SCROLL_KEY, JSON.stringify(position));
    logPerf('scroll-save', getScrollDiagnostics(position));
  } catch (_e) {
    // Scroll position is a convenience only.
  }
}

function clearScrollPosition() {
  if (scrollSaveTimer) {
    clearTimeout(scrollSaveTimer);
    scrollSaveTimer = 0;
  }
  localStorage.removeItem(POPUP_SCROLL_KEY);
}

function scheduleScrollPositionWrite(data = {}) {
  if (scrollPersistenceSuppressed || normalizeOpenPositionMode(openPositionModeEl.value) !== 'free') return;
  if (scrollSaveTimer) clearTimeout(scrollSaveTimer);
  scrollSaveTimer = setTimeout(() => {
    scrollSaveTimer = 0;
    if (scrollPersistenceSuppressed) return;
    writeScrollPosition(data);
  }, POPUP_SCROLL_SAVE_DELAY_MS);
}

function suppressScrollPersistenceForFrames(frameCount = 3) {
  if (scrollSaveTimer) {
    clearTimeout(scrollSaveTimer);
    scrollSaveTimer = 0;
  }
  scrollPersistenceSuppressed = true;
  let remaining = Math.max(1, frameCount);
  const release = () => {
    if (--remaining > 0) {
      requestAnimationFrame(release);
      return;
    }
    scrollPersistenceSuppressed = false;
  };
  requestAnimationFrame(release);
}

function getFirstVisibleItem() {
  const listTop = historyList.getBoundingClientRect().top;
  const items = historyList.querySelectorAll('.item');
  for (const item of items) {
    if (item.getBoundingClientRect().bottom >= listTop) return item;
  }
  return items[0] || null;
}

function restoreScrollPosition(data) {
  const position = readScrollPosition();
  const beforeScrollTop = historyList.scrollTop;
  if (!position) {
    logPerf('scroll-restore', { result: 'missing', beforeScrollTop });
    return false;
  }

  const context = getScrollContext(data);
  if (position.feedMode !== context.feedMode || position.historyDays !== context.historyDays) {
    logPerf('scroll-restore', {
      result: 'context-mismatch',
      beforeScrollTop,
      currentFeedMode: context.feedMode,
      currentHistoryDays: context.historyDays,
      ...getScrollDiagnostics(position)
    });
    return false;
  }

  // Content above the saved item can change between popup sessions.
  if ((position.anchorKey || position.anchorUrl) && Number.isFinite(position.offsetTop)) {
    if (restoreScrollAnchor(historyList, {
      scrollTop: position.scrollTop,
      anchorKey: position.anchorKey || '',
      anchorUrl: position.anchorUrl,
      offsetTop: position.offsetTop,
      anchorWasUnreadWatch: position.anchorWasUnreadWatch,
      anchorWasPinnedWatch: position.anchorWasPinnedWatch
    })) {
      logPerf('scroll-restore', {
        result: 'anchor',
        beforeScrollTop,
        afterScrollTop: historyList.scrollTop,
        ...getScrollDiagnostics(position)
      });
      return true;
    }
  }

  if (Number.isFinite(position.scrollTop)) {
    historyList.scrollTop = Math.max(position.scrollTop, 0);
    logPerf('scroll-restore', {
      result: 'scroll-top',
      beforeScrollTop,
      afterScrollTop: historyList.scrollTop,
      ...getScrollDiagnostics(position)
    });
    return true;
  }

  logPerf('scroll-restore', { result: 'invalid', beforeScrollTop, ...getScrollDiagnostics(position) });
  return false;
}

function applyInitialPosition(data) {
  if (normalizeOpenPositionMode(data.openPositionMode) === 'free' && restoreScrollPosition(data)) return;
  scrollToFirstUnread();
}

function getReadAllBefore(data) {
  return [data.readAllBefore, ...Object.values(data.readAllBeforeByMode || {})]
    .filter(value => value && Number.isFinite(new Date(value).getTime()))
    .reduce((latest, value) => !latest || new Date(value) > new Date(latest) ? value : latest, '');
}

function getItemTime(item) {
  return new Date(item.time || item.discoveredAt || 0).getTime();
}

function getUnreadReferenceTime(item) {
  const itemTime = getItemTime(item);
  const discoveredAt = new Date(item.discoveredAt || item.time).getTime();
  // A future publication time cannot make an item newer than its discovery.
  const cappedItemTime = Number.isFinite(discoveredAt) && Number.isFinite(itemTime)
    ? Math.min(itemTime, discoveredAt)
    : itemTime;
  return Math.max(
    Number.isFinite(cappedItemTime) ? cappedItemTime : 0,
    Number.isFinite(discoveredAt) ? discoveredAt : 0
  );
}

function isWithinHistoryWindow(item, cutoff) {
  return getUnreadReferenceTime(item) > cutoff;
}

function isWithinDisplayWindow(item, cutoff) {
  const publishedAt = new Date(item?.time || 0).getTime();
  return Number.isFinite(publishedAt) && publishedAt > cutoff;
}

function mergeReadIds(current = [], cached = []) {
  const merged = [...new Set([...current, ...cached])];
  return merged.length > 100 ? merged.slice(merged.length - 100) : merged;
}

function sameStringArray(a = [], b = []) {
  if (a.length !== b.length) return false;
  return a.every((value, index) => value === b[index]);
}

function reconcileCachedReadIds(data, cachedData) {
  if (!cachedData || !cachedData.readIds) return { data, changed: false };

  const mergedReadIds = mergeReadIds(data.readIds || [], cachedData.readIds || []);
  if (sameStringArray(mergedReadIds, data.readIds || [])) {
    return { data, changed: false };
  }

  return {
    data: {
      ...data,
      readIds: mergedReadIds
    },
    changed: true
  };
}

function normalizeReadAllBeforeData(data) {
  data.readAllBefore = getReadAllBefore(data);
  data.readAllBeforeByMode = {};
}

function applyTheme(theme) {
  theme = normalizeTheme(theme);
  document.documentElement.setAttribute('data-theme', theme);
  const themeBackgrounds = {
    'dark': '#101010',
    'green-dark': '#0c0f10',
    'chrome-dark': '#111317',
    'slate-night': '#0b1418'
  };
  document.documentElement.style.background = themeBackgrounds[theme] || '#101010';
  document.documentElement.style.colorScheme = 'dark';
  localStorage.setItem('theme', theme);
}

function applyFontSize(size) {
  document.documentElement.setAttribute('data-size', size);
  localStorage.setItem('fontSize', size);
}

function applyFontFamily(font) {
  font = normalizeFontFamily(font);
  document.documentElement.setAttribute('data-font', font);
  localStorage.setItem('fontFamily', font);
}

function applyConfig(data, options = {}) {
  enabledEl.checked = data.enabled !== false;
  let interval = data.interval || 2;
  if (interval < 2) interval = 2;
  intervalEl.value = String(interval);
  if (options.preserveFeedMode !== true) feedModeEl.value = normalizeFeedMode(data.feedMode);
  const theme = normalizeTheme(data.theme);
  themeEl.value = theme;
  applyTheme(theme);
  const font = normalizeFontFamily(data.fontFamily);
  fontFamilyEl.value = font;
  applyFontFamily(font);
  const size = data.fontSize || 'medium';
  fontSizeEl.value = size;
  applyFontSize(size);
  openPositionModeEl.value = normalizeOpenPositionMode(data.openPositionMode);
  let days = data.historyDays || DEFAULT_HISTORY_DAYS;
  if (days > 5) days = 5;
  historyDaysEl.value = String(days);
  renderWatchRules(data.watchRules || []);
}

function applyRenderPosition(data, options = {}) {
  if (options.scrollAnchor) {
    restoreScrollAnchor(historyList, options.scrollAnchor);
    return;
  }
  if (options.applyInitialPosition === true) applyInitialPosition(data);
}

function renderHistory(data, options = {}) {
  const skipUnchanged = options.skipUnchanged !== false;
  const rawHistory = projectHistory(data.history || [], data.feedMode);
  const readIds = data.readIds || [];
  const readAllBefore = getReadAllBefore(data);
  const historyDays = data.historyDays || DEFAULT_HISTORY_DAYS;
  const watchRules = normalizeWatchRules(data.watchRules || []);

  const readIdSet = new Set(readIds);
  cachedReadIds = readIdSet;
  const readAllBeforeTime = readAllBefore ? new Date(readAllBefore).getTime() : 0;

  const cutoff = Date.now() - historyDays * 24 * 60 * 60 * 1000;
  const history = rawHistory.filter(i => isWithinDisplayWindow(i, cutoff));
  const signature = buildHistoryRenderSignature(
    history,
    historyDays,
    watchRules,
    item => isReadFast(item, readIdSet, readAllBeforeTime)
  );
  logPerf('render-start', { items: history.length, cached: signature === lastRenderSignature });

  // Seed the session watch-pin tracker before the skip-unchanged guard. When a
  // later storage read has the same signature, currently-unread watch keys still
  // need to enter the session set so they remain pinned after becoming read.
  const pinnedWatch = sortWatchItemsByRulePriority(sessionWatchPinTracker
    .getPinnedItems(
      history,
      item => !isReadFast(item, readIdSet, readAllBeforeTime),
      getItemStateKey,
      {
        persistUnread: options.persistWatchPins !== false,
        isWatchMatch: item => hasActiveWatchRuleMatch(item, watchRules)
      }
    ), watchRules, getItemTime);

  if (skipUnchanged && signature === lastRenderSignature) {
    applyRenderPosition(data, options);
    refreshUnreadNavigatorFromDom();
    updateHistoryScrollControls();
    logPerf('render-skip', { items: history.length });
    return;
  }

  if (history.length === 0) {
    const tip = rawHistory.length > 0
      ? `当前${historyDays}天内无记录，记录会随轮询逐步积累`
      : '暂无内容，等待下一次推送';
    historyList.innerHTML = `<div class="empty-state">${tip}</div>`;
    if (!markAllReadBtn.classList.contains('is-confirmed')) {
      markAllReadBtn.classList.remove('visible');
    }
    updateUnreadNavigator(0);
    applyRenderPosition(data, options);
    updateHistoryScrollControls();
    lastRenderSignature = signature;
    logPerf('render-end', { items: 0, empty: true });
    return;
  }

  const unread = history.filter(i => !isReadFast(i, readIdSet, readAllBeforeTime)).length;
  if (unread > 0) {
    markAllReadBtn.classList.add('visible');
  } else if (!markAllReadBtn.classList.contains('is-confirmed')) {
    // Only hide if not currently showing confirmation animation
    markAllReadBtn.classList.remove('visible');
  }

  const pinnedKeys = new Set(pinnedWatch.map(item => getItemStateKey(item)));
  const displayHistory = [...pinnedWatch, ...history.filter(item => !pinnedKeys.has(getItemStateKey(item)))];

  let html = '';
  pinnedWatch.forEach(item => {
    html += renderItemHtml(item, !isReadFast(item, readIdSet, readAllBeforeTime), { watchPinned: true });
  });

  displayHistory.filter(item => !pinnedKeys.has(getItemStateKey(item))).forEach(item => {
    const isUnread = !isReadFast(item, cachedReadIds, readAllBeforeTime);
    html += renderItemHtml(item, isUnread);
  });

  historyList.innerHTML = html;
  applyRenderPosition(data, options);
  refreshUnreadNavigatorFromDom();
  updateHistoryScrollControls();
  lastRenderSignature = signature;
  logPerf('render-end', { items: history.length, unread });
}

function scrollToFirstUnread() {
  const firstUnread = historyList.querySelector('.item.unread');
  if (!firstUnread) return;
  historyList.scrollTop = Math.max(firstUnread.offsetTop - historyList.offsetTop - 6, 0);
}

function updateUnreadNavigator(count, hasVisibleUnread = false) {
  const unread = Math.max(Number(count) || 0, 0);
  if (!jumpToUnreadBtn) return;
  const isAvailable = unread > 0 && !hasVisibleUnread;
  jumpToUnreadBtn.classList.toggle('visible', isAvailable);
  jumpToUnreadBtn.setAttribute('aria-hidden', String(!isAvailable));
  jumpToUnreadBtn.tabIndex = isAvailable ? 0 : -1;
  jumpToUnreadBtn.title = '跳到未读';
  jumpToUnreadBtn.setAttribute('aria-label', '跳到未读');
}

function isHistoryItemVisible(item) {
  const listRect = historyList.getBoundingClientRect();
  const rect = item.getBoundingClientRect();
  return rect.bottom > listRect.top && rect.top < listRect.bottom;
}

function refreshUnreadNavigatorFromDom() {
  const unreadItems = Array.from(historyList.querySelectorAll('.item.unread'));
  updateUnreadNavigator(unreadItems.length, unreadItems.some(isHistoryItemVisible));
}

function jumpToUnread() {
  const unreadItems = Array.from(historyList.querySelectorAll('.item.unread'));
  if (unreadItems.length === 0) {
    updateUnreadNavigator(0);
    return null;
  }
  if (unreadItems.some(isHistoryItemVisible)) {
    refreshUnreadNavigatorFromDom();
    return null;
  }
  const getItemTop = item => Number(item.offsetTop) - Number(historyList.offsetTop || 0);
  const listRect = historyList.getBoundingClientRect();
  const next = unreadItems.find(item => item.getBoundingClientRect().top >= listRect.bottom) || unreadItems[0];
  const targetTop = Math.max(getItemTop(next) - 6, 0);
  if (typeof historyList.scrollTo === 'function') {
    historyList.scrollTo({ top: targetTop, behavior: 'auto' });
  } else {
    historyList.scrollTop = targetTop;
  }
  refreshUnreadNavigatorFromDom();
  historyList.querySelectorAll('.item.is-jump-target').forEach(item => item.classList.remove('is-jump-target'));
  next.classList.add('is-jump-target');
  if (unreadJumpTimer) clearTimeout(unreadJumpTimer);
  unreadJumpTimer = setTimeout(() => {
    next.classList.remove('is-jump-target');
    unreadJumpTimer = 0;
  }, 750);
  return next.dataset.key || next.dataset.url || null;
}

function cacheLoadedPopupData(data) {
  const feedMode = normalizeFeedMode(data.feedMode);
  writePopupCache({
    enabled: data.enabled,
    interval: data.interval,
    feedMode,
    theme: data.theme,
    fontFamily: normalizeFontFamily(data.fontFamily),
    fontSize: data.fontSize,
    openPositionMode: normalizeOpenPositionMode(data.openPositionMode),
    historyDays: data.historyDays,
    history: projectHistory(data.history || [], feedMode),
    readIds: data.readIds || [],
    readAllBefore: data.readAllBefore || '',
    readAllBeforeByMode: data.readAllBeforeByMode || {},
    watchRules: data.watchRules || []
  });
}

function isReadFast(item, readIdSet, readAllBeforeTime) {
  if (getItemAliases(item).some(alias => readIdSet.has(alias))) return true;
  if (readAllBeforeTime && getUnreadReferenceTime(item) <= readAllBeforeTime) return true;
  return false;
}

function normalizeConfigSnapshot(data = {}) {
  return {
    enabled: data.enabled !== false,
    interval: Math.max(Number(data.interval) || 2, 2),
    theme: normalizeTheme(data.theme),
    fontFamily: normalizeFontFamily(data.fontFamily),
    fontSize: data.fontSize || 'medium',
    openPositionMode: normalizeOpenPositionMode(data.openPositionMode),
    historyDays: Math.min(Math.max(Number(data.historyDays) || DEFAULT_HISTORY_DAYS, 1), 5)
  };
}

function readConfigControls() {
  return normalizeConfigSnapshot({
    enabled: enabledEl.checked,
    interval: intervalEl.value,
    theme: themeEl.value,
    fontFamily: fontFamilyEl.value,
    fontSize: fontSizeEl.value,
    openPositionMode: openPositionModeEl.value,
    historyDays: historyDaysEl.value
  });
}

function applyConfigSnapshot(config) {
  enabledEl.checked = config.enabled;
  intervalEl.value = String(config.interval);
  themeEl.value = config.theme;
  fontFamilyEl.value = config.fontFamily;
  fontSizeEl.value = config.fontSize;
  openPositionModeEl.value = config.openPositionMode;
  historyDaysEl.value = String(config.historyDays);
  applyTheme(config.theme);
  applyFontFamily(config.fontFamily);
  applyFontSize(config.fontSize);
  writePopupCache(config);
}

const configMutationController = createConfigMutationController({
  getCommitted: () => lastCommittedConfig,
  setCommitted: config => { lastCommittedConfig = { ...config }; },
  apply: applyConfigSnapshot,
  persist: config => chrome.storage.local.set(config),
  notify: () => chrome.runtime.sendMessage({ type: 'configChanged' })
});

async function saveConfig(options = {}) {
  const config = readConfigControls();
  applyConfigSnapshot(config);
  if (config.openPositionMode === 'unread') clearScrollPosition();
  await configMutationController.save(config, options);
  showPopupStatus('');
  loadHistory(undefined, { immediate: true }).catch(() => showPopupStatus('内容加载失败，请重试。'));
}

function saveConfigWithStatus(options = {}) {
  return saveConfig(options).catch(error => {
    showPopupStatus(error.committed
      ? '设置已保存，但后台更新失败，请重试。'
      : '设置保存失败，请重试。');
    throw error;
  });
}

const POPUP_HISTORY_STORAGE_KEYS = [
  'enabled', 'interval', 'theme', 'fontFamily', 'fontSize',
  'history', 'readIds', 'readAllBefore', 'readAllBeforeByMode', 'historyDays',
  'feedMode', 'openPositionMode', 'watchRules', 'allFeedContinuation'
];

const POPUP_INITIAL_STORAGE_KEYS = [
  'enabled', 'interval', 'feedMode', 'theme', 'fontFamily', 'fontSize', 'openPositionMode', 'historyDays',
  'history', 'readIds', 'readAllBefore', 'readAllBeforeByMode', 'watchRules'
];

const historyLoadController = createLatestWinsLoadController({
  read: async mode => {
    const [data, cachedData] = await Promise.all([
      chrome.storage.local.get(POPUP_HISTORY_STORAGE_KEYS),
      readWarmPopupCache(mode)
    ]);
    const reconciled = reconcileCachedReadIds(data, cachedData);
    return {
      ...reconciled.data,
      committedFeedMode: normalizeFeedMode(data.feedMode)
    };
  },
  projectHistory,
  normalizeFeedMode,
  getSwitchRequestId: () => feedModeSwitchController?.getState().switchRequestId || 0,
  captureScrollAnchor: () => captureScrollAnchor(historyList),
  commit: (data, context) => {
    if (feedModeSwitchController) {
      feedModeSwitchController.observeCommittedMode(data.committedFeedMode);
      if (feedModeSwitchController.getState().pendingMode === null) feedModeEl.value = data.feedMode;
    }
    renderHistory(data, {
      applyInitialPosition: context.applyInitialPosition,
      skipUnchanged: !context.forceRender,
      scrollAnchor: context.scrollAnchor
    });
    showPopupStatus('');
    allFeedContinuationStatusController.update(data.allFeedContinuation);
    cacheLoadedPopupData(data);
  },
  onError: () => showPopupStatus('内容加载失败，请重试。')
});

function loadHistory(mode, options = {}) {
  const activeMode = normalizeFeedMode(mode || feedModeSwitchController?.getDisplayMode() || feedModeEl.value);
  const switchRequestId = options.switchRequestId === undefined
    ? (feedModeSwitchController?.getState().switchRequestId || 0)
    : options.switchRequestId;
  return historyLoadController.loadProjection(activeMode, { ...options, switchRequestId });
}

chrome.storage.onChanged.addListener(createPopupStorageChangeHandler({
  getFeedMode: changes => {
    const state = feedModeSwitchController?.getState();
    if (state?.pendingMode) return state.pendingMode;
    if (changes.feedMode) return normalizeFeedMode(changes.feedMode.newValue);
    return feedModeSwitchController?.getDisplayMode() || feedModeEl.value;
  },
  getSwitchRequestId: () => feedModeSwitchController?.getState().switchRequestId || 0,
  updateContinuationStatus: continuation => allFeedContinuationStatusController.update(continuation),
  scheduleLoad: historyLoadController.scheduleLoad
}));

async function handleItemClick(e) {
  const item = e.target.closest('.item');
  if (!item) return;
  await openHistoryItem(item);
}

async function openHistoryItem(item) {
  const url = getSafeHttpsUrl(item.dataset.url);
  if (!url) {
    showPopupStatus('无法打开此条目：链接必须使用 HTTPS。');
    return;
  }
  const key = item.dataset.key || url;
  const scrollAnchor = captureScrollAnchor(historyList);
  const previousReadIds = new Set(cachedReadIds);
  const optimisticAliases = [key, url].filter(alias => alias && !previousReadIds.has(alias));
  const elements = Array.from(document.querySelectorAll(`.item[data-key="${CSS.escape(key)}"], .item[data-url="${CSS.escape(url)}"]`));
  const previousUnread = new Map(elements.map(el => [el, el.classList.contains('unread')]));

  const applyOptimistic = () => {
    if (!cachedReadIds.has(key)) {
      cachedReadIds.add(key);
      if (url !== key) cachedReadIds.add(url);
      const arr = [...cachedReadIds];
      if (arr.length > 100) arr.splice(0, arr.length - 100);
      writePopupCache({ readIds: arr });
      lastRenderSignature = '';
    }
    elements.forEach(el => {
      el.classList.remove('unread');
      el.classList.add('read');
    });
    const unreadEls = document.querySelectorAll('.item.unread');
    refreshUnreadNavigatorFromDom();
    if (unreadEls.length > 0) markAllReadBtn.classList.add('visible');
    else if (!markAllReadBtn.classList.contains('is-confirmed')) markAllReadBtn.classList.remove('visible');
  };
  const rollback = () => {
    cachedReadIds = removeOptimisticReadAliases(cachedReadIds, optimisticAliases, previousReadIds);
    writePopupCache({ readIds: [...cachedReadIds] });
    lastRenderSignature = '';
    previousUnread.forEach((wasUnread, el) => {
      if (wasUnread) {
        el.classList.remove('read');
        el.classList.add('unread');
      }
    });
    if (Array.from(previousUnread.values()).some(Boolean)) {
      markAllReadBtn.classList.add('visible');
    }
    refreshUnreadNavigatorFromDom();
  };

  const result = await runOpenItemMutation({
    applyOptimistic,
    rollback,
    open: () => chrome.runtime.sendMessage({ type: 'openItem', url, ids: [key, url] }),
    onFailure: reason => showPopupStatus(reason === 'unsafe-url'
      ? '无法打开此条目：链接必须使用 HTTPS。'
      : '打开条目失败，请重试。'),
    onPersistenceFailure: () => showPopupStatus('条目已打开，但已读状态更新失败，请重试。')
  });
  const scrollCtx = await chrome.storage.local.get(['feedMode', 'historyDays']);
  writeScrollPosition(
    { feedMode: normalizeFeedMode(scrollCtx.feedMode), historyDays: scrollCtx.historyDays || DEFAULT_HISTORY_DAYS },
    scrollAnchor
  );

  return result;
}

// Event delegation for item clicks
historyList.addEventListener('click', handleItemClick);
historyList.addEventListener('keydown', async (e) => {
  const isOpenKey = e.key === 'Enter' || e.key === ' ';
  if (!isOpenKey) return;
  const item = e.target.closest('.item');
  if (!item) return;
  e.preventDefault();
  await openHistoryItem(item);
});

markAllReadBtn.addEventListener('click', async () => {
  markAllReadBtn.disabled = true;
  const feedbackStartedAt = Date.now();
  const scrollAnchor = captureScrollAnchor(historyList);
  const rollbackOptimisticReadState = applyOptimisticReadState(historyList.querySelectorAll('.item'), markAllReadBtn);
  restoreScrollAnchor(historyList, scrollAnchor);
  const now = new Date().toISOString();
  refreshUnreadNavigatorFromDom();
  try {
    await runMarkAllReadMutation({
      send: () => chrome.runtime.sendMessage({ type: 'markAllRead', readAllBefore: now }),
      rollback: () => {
        rollbackOptimisticReadState();
        restoreScrollAnchor(historyList, scrollAnchor);
      },
      reload: () => loadHistory(undefined, { immediate: true, forceRender: true, scrollAnchor }),
      onCommitted: () => {
        showButtonResult(markAllReadBtn, 'is-result-accent', Date.now() - feedbackStartedAt);
        clearScrollPosition();
      },
      onFailure: ({ committed, recovered }) => {
        refreshUnreadNavigatorFromDom();
        if (committed && recovered) return;
        showButtonResult(markAllReadBtn, 'is-result-danger', Date.now() - feedbackStartedAt);
        showPopupStatus(committed
          ? '全部已读已生效，但列表刷新失败，请重试。'
          : '全部已读失败，请重试。');
      }
    });
  } finally {
    markAllReadBtn.disabled = false;
  }
});

const settingGroups = Array.from(settingsPanel.querySelectorAll('.setting-group'));
const settingsPanelController = popupReliability.createSettingsPanelController({
  panel: settingsPanel,
  trigger: settingsBtn,
  groups: settingGroups
});
function collapseSettingsGroups() {
  settingsPanelController.collapseGroups();
}

function setSettingsOpen(isOpen, { focus = true } = {}) {
  settingsPanelController.setOpen(isOpen, { focus });
}

settingsPanel.addEventListener('transitionrun', event => {
  if (event.propertyName !== 'max-height' || !activeSettingsTrace) return;
  logPerf('settings-transition-run', {
    id: activeSettingsTrace.id,
    nextOpen: activeSettingsTrace.nextOpen,
    elapsedMs: Number((performance.now() - activeSettingsTrace.startedAt).toFixed(2))
  });
});

settingsPanel.addEventListener('transitionend', event => {
  if (event.propertyName !== 'max-height') return;
  // The panel remains in normal document flow; only refresh edge controls
  // after its height transition has settled.
  requestAnimationFrame(() => updateHistoryScrollControls({ readScrollHeight: false }));
  if (!activeSettingsTrace) return;
  logPerf('settings-transition-end', {
    id: activeSettingsTrace.id,
    nextOpen: activeSettingsTrace.nextOpen,
    elapsedMs: Number((performance.now() - activeSettingsTrace.startedAt).toFixed(2))
  });
  activeSettingsTrace = null;
});

settingsBtn.addEventListener('click', () => {
  const nextOpen = !settingsPanel.classList.contains('open');
  beginSettingsTrace(nextOpen);
  settingsPanelController.toggle();
  requestAnimationFrame(updateSettingsScrollHint);
});

settingGroups.forEach(group => {
  group.addEventListener('toggle', () => {
    if (!group.open) return;
    settingGroups.forEach(otherGroup => {
      if (otherGroup !== group) otherGroup.open = false;
    });
    if (group.dataset.settingGroup === 'watch') {
      requestAnimationFrame(updateWatchRulesScrollHint);
    }
    requestAnimationFrame(updateSettingsScrollHint);
  });
});

if (settingsInnerEl) {
  settingsInnerEl.addEventListener('scroll', updateSettingsScrollHint, { passive: true });
}

document.getElementById('copyLogs').addEventListener('click', function() {
  const log = window.__popupPerf && window.__popupPerf.snapshot ? window.__popupPerf.snapshot().join('\n') : '';
  navigator.clipboard.writeText(log).then(() => {
    this.textContent = '成功';
    setTimeout(() => { this.textContent = '拷贝'; }, 1500);
  });
});


if (addWatchRuleBtn) {
  addWatchRuleBtn.addEventListener('click', async () => {
    const source = watchSourceEl.value.trim();
    const author = watchAuthorEl.value.trim();
    const keywords = splitWatchKeywords(watchKeywordsEl.value);
    if (!source && !author && keywords.length === 0) return;
    try {
      await enqueuePopupMutation(async () => {
        const { watchRules = [] } = await chrome.storage.local.get('watchRules');
        const nextRules = mergeWatchRuleInput(watchRules, { source, author, keywords });
        await saveWatchRules(nextRules, { scrollToEnd: true });
        watchKeywordsEl.value = '';
      });
    } catch (_e) {
      showPopupStatus('保存特关规则失败，请重试。');
    }
  });
}

if (watchRulesList) {
  watchRulesList.addEventListener('scroll', updateWatchRulesScrollHint, { passive: true });
  watchRulesList.addEventListener('click', async (e) => {
    try {
      await enqueuePopupMutation(async () => {
        const keywordRemoveBtn = e.target.closest('.watch-keyword-remove');
        if (keywordRemoveBtn) {
          const card = keywordRemoveBtn.closest('.watch-rule-card');
          const ruleId = card?.dataset.ruleId;
          const keywordIndex = Number(keywordRemoveBtn.dataset.keywordIndex);
          if (!ruleId || !Number.isInteger(keywordIndex)) return;
          const { watchRules = [] } = await chrome.storage.local.get('watchRules');
          await saveWatchRules(removeWatchRuleKeyword(watchRules, ruleId, keywordIndex));
          return;
        }

        const button = e.target.closest('.watch-rule-btn');
        if (!button) return;
        const card = button.closest('.watch-rule-card');
        const ruleId = card?.dataset.ruleId;
        if (!ruleId) return;
        const { watchRules = [] } = await chrome.storage.local.get('watchRules');
        const rules = normalizeWatchRules(watchRules);
        const action = button.dataset.action;
        const nextRules = action === 'delete'
          ? rules.filter(rule => rule.id !== ruleId)
          : action === 'move-up'
            ? moveWatchRule(rules, ruleId, -1)
            : action === 'move-down'
              ? moveWatchRule(rules, ruleId, 1)
              : rules.map(rule => rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule);
        const preservesFocus = action !== 'delete';
        const isMove = action === 'move-up' || action === 'move-down';
        await saveWatchRules(nextRules, {
          focusRuleId: preservesFocus ? ruleId : undefined,
          focusAction: preservesFocus ? action : undefined,
          movedRuleId: isMove ? ruleId : undefined
        });
      });
    } catch (_e) {
      showPopupStatus('更新特关规则失败，请重试。');
    }
  });
}

enabledEl.addEventListener('change', () => { void saveConfigWithStatus().catch(() => {}); });
intervalEl.addEventListener('change', () => { void saveConfigWithStatus().catch(() => {}); });
feedModeSwitchController = createFeedModeSwitchController({
  initialMode: normalizeFeedMode(readPopupCache()?.feedMode || feedModeEl.value),
  normalizeFeedMode,
  setDisabled: disabled => { feedModeEl.disabled = disabled; },
  sendChange: feedMode => chrome.runtime.sendMessage({ type: 'feedModeChanged', feedMode }),
  loadProjection: loadHistory,
  readCommittedMode: async () => {
    const { feedMode } = await chrome.storage.local.get('feedMode');
    return feedMode;
  },
  getFailCount: async () => {
    const { failCount = 0 } = await chrome.storage.local.get('failCount');
    return failCount;
  },
  clearScrollPosition,
  rollback: async feedMode => {
    feedModeEl.value = feedMode;
  },
  onSuccess: (failCount, feedbackStartedAt, feedMode) => {
    feedModeEl.value = feedMode;
    showButtonResult(pollBtn, failCount === 0 ? 'is-result-accent' : 'is-result-danger', Date.now() - feedbackStartedAt);
  },
  onFailure: feedbackStartedAt => {
    showButtonResult(pollBtn, 'is-result-danger', Date.now() - feedbackStartedAt);
    showPopupStatus('切换内容源失败，已恢复原选择。');
  }
});

feedModeEl.addEventListener('change', async () => {
  const feedbackStartedAt = Date.now();
  const nextFeedMode = normalizeFeedMode(feedModeEl.value);
  clearButtonFeedback(pollBtn);
  pollBtn.classList.add('is-loading');
  await feedModeSwitchController.switchFeedMode(nextFeedMode, feedbackStartedAt);
});
themeEl.addEventListener('change', () => { void saveConfigWithStatus({ notifyBackground: false }).catch(() => {}); });
fontFamilyEl.addEventListener('change', () => { void saveConfigWithStatus({ notifyBackground: false }).catch(() => {}); });
fontSizeEl.addEventListener('change', () => { void saveConfigWithStatus({ notifyBackground: false }).catch(() => {}); });
openPositionModeEl.addEventListener('change', () => { void saveConfigWithStatus({ notifyBackground: false }).catch(() => {}); });
historyDaysEl.addEventListener('change', () => {
  clearScrollPosition();
  void saveConfigWithStatus({ notifyBackground: false }).catch(() => {});
});

historyList.addEventListener('scroll', event => {
  logPerf('scroll-event', {
    scrollTop: Math.round(historyList.scrollTop * 10) / 10,
    trusted: event?.isTrusted === true,
    mode: normalizeOpenPositionMode(openPositionModeEl.value)
  });
  refreshUnreadNavigatorFromDom();
  updateHistoryScrollControls();
  const data = {
    feedMode: feedModeEl.value,
    historyDays: Number(historyDaysEl.value)
  };
  scheduleScrollPositionWrite(data);
}, { passive: true });

scrollToTopBtn.addEventListener('click', () => scrollHistoryTo(0));
scrollToBottomBtn.addEventListener('click', () => scrollHistoryTo(historyList.scrollHeight));
jumpToUnreadBtn.addEventListener('click', jumpToUnread);

pollBtn.addEventListener('click', async () => {
  const feedbackStartedAt = Date.now();
  // Save synchronously in case the popup closes before the request completes.
  writeScrollPosition({ feedMode: feedModeEl.value, historyDays: Number(historyDaysEl.value) });
  clearButtonFeedback(pollBtn);
  pollBtn.classList.add('is-loading');
  pollBtn.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({ type: 'pollNow' });
    if (!response || response.ok === false) throw new Error(response?.error || 'manual poll failed');
    const { failCount = 0 } = await chrome.storage.local.get('failCount');
    await loadHistory();
    // A skipped render may emit no scroll event; persist the current anchor explicitly.
    writeScrollPosition({ feedMode: feedModeEl.value, historyDays: Number(historyDaysEl.value) });
    showButtonResult(pollBtn, failCount === 0 ? 'is-result-accent' : 'is-result-danger', Date.now() - feedbackStartedAt);
  } catch (e) {
    showButtonResult(pollBtn, 'is-result-danger', Date.now() - feedbackStartedAt);
    showPopupStatus('刷新失败，请重试。');
  }
  pollBtn.disabled = false;
});

// Cold starts paint the skeleton; warm starts preview cached content while
// authoritative storage loads, without holding the popup on a loading state.
logPerf('init-start');
const popupInitializationController = createPopupInitializationController({
  getLoadVersion: historyLoadController.getVersion,
  getSwitchState: feedModeSwitchController.getState,
  normalizeFeedMode,
  readCommittedMode: async () => {
    const { feedMode } = await chrome.storage.local.get('feedMode');
    return feedMode;
  },
  readWarmCache: () => readWarmPopupCache(),
  readFullStorage: () => chrome.storage.local.get(POPUP_INITIAL_STORAGE_KEYS),
  onCacheResolved: cachedData => logPerf(cachedData ? 'cache-hit' : 'cache-miss'),
  applyCache: data => {
    applyConfig(data);
    feedModeSwitchController.observeCommittedMode(data.feedMode);
  },
  waitForPaint: waitForNextPaint,
  renderCache: data => {
    const beforeScrollTop = historyList.scrollTop;
    renderHistory(data, { applyInitialPosition: true, persistWatchPins: false });
    suppressScrollPersistenceForFrames();
    logPerf('scroll-render', { phase: 'cache', beforeScrollTop, afterScrollTop: historyList.scrollTop });
    logPerf('render-cache');
  },
  onStorageResolved: () => logPerf('storage-ready'),
  prepareStorage: (storageData, cachedData) => {
    const reconciled = reconcileCachedReadIds(storageData, cachedData);
    const data = reconciled.data;
    normalizeReadAllBeforeData(data);
    data.feedMode = normalizeFeedMode(data.feedMode);
    data.history = projectHistory(data.history || [], data.feedMode);
    return data;
  },
  applyStorage: data => {
    feedModeSwitchController.observeCommittedMode(data.feedMode);
    const acceptedConfig = configMutationController.observeCommitted(normalizeConfigSnapshot(data));
    if (acceptedConfig !== false) applyConfig(data);
    if (data.theme && data.theme !== normalizeTheme(data.theme)) {
      chrome.storage.local.set({ theme: 'dark' });
    }
    if (data.fontFamily && data.fontFamily !== normalizeFontFamily(data.fontFamily)) {
      chrome.storage.local.set({ fontFamily: 'system' });
    }
  },
  renderStorage: data => {
    const beforeScrollTop = historyList.scrollTop;
    const scrollAnchor = captureScrollAnchor(historyList);
    renderHistory(data, scrollAnchor?.anchorUrl
      ? { scrollAnchor }
      : { applyInitialPosition: true });
    suppressScrollPersistenceForFrames();
    logPerf('scroll-render', {
      phase: 'storage',
      beforeScrollTop,
      afterScrollTop: historyList.scrollTop,
      anchor: getScrollDiagnostics(scrollAnchor || {})
    });
    logPerf('render-storage');
    cacheLoadedPopupData(data);
    markPopupSessionWarm();
  }
});
popupInitializationController.initialize()
  .catch(() => showPopupStatus('内容加载失败，请重试。'));
